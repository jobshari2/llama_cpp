# LlamaForge — User Guide

> The "NVIDIA Control Panel" for [llama.cpp](https://github.com/ggml-org/llama.cpp).
> Detect your hardware, recommend quantizations, benchmark configurations, and run inference — all from a modern web UI.

---

## Table of contents

1. [Installation](#installation)
2. [The Dashboard](#1-dashboard)
3. [Configuration](#2-configuration)
4. [Models](#3-models)
5. [Presets](#4-presets)
6. [Benchmark](#5-benchmark)
7. [Optimization (auto-tuning)](#6-optimization)
8. [Playground](#7-playground)
9. [TensorRT-LLM](#8-tensorrt-llm)
10. [Jetson tuning](#9-jetson-tuning)
11. [Settings](#10-settings)
12. [Architecture](#architecture)
13. [Storage layout](#storage-layout)
14. [Security model](#security-model)
15. [API reference](#api-reference)

---

## Installation

### Prerequisites

| Component | Notes |
|-----------|-------|
| Python 3.12+ | Backend |
| Node.js 20+ | Frontend |
| CMake + Ninja + C++ toolchain | To build llama.cpp |
| (Optional) CUDA Toolkit 12+ | GPU acceleration |
| (Optional) JetPack | Jetson Orin Nano |

### One-time setup

```bash
# 1. Build llama.cpp (auto-detects CUDA / Jetson)
./scripts/install_llama_cpp.sh        # Linux / Jetson
.\scripts\install_llama_cpp.ps1        # Windows

# 2. Backend
cd backend
python -m venv .venv && . .venv/bin/activate     # POSIX
# . .venv/Scripts/Activate.ps1                   # Windows
pip install -r requirements.txt
uvicorn app.main:app --reload

# 3. Frontend (separate terminal)
cd frontend
npm install
npm run dev
```

Open http://localhost:5173.

### Docker

```bash
docker compose -f docker/docker-compose.yml up --build
# UI: http://localhost:8080  · API: http://localhost:8000
```

The backend container expects an NVIDIA runtime with the GPU exposed.

---

## 1. Dashboard

**What it shows.** A live overview of your system: GPU name, VRAM, GPU utilisation, temperature, CPU, RAM, swap, and storage devices. If a Jetson is detected, JetPack version and power mode are surfaced.

**Live updates.** A WebSocket pushes a fresh snapshot every second. The chart shows GPU utilisation, VRAM use, and temperature on a 60 s rolling window.

**Why it matters.** When you tweak a parameter or run a benchmark, the dashboard tells you whether you're CPU-bound, memory-bound, or thermally throttled — without leaving the UI.

---

## 2. Configuration

The Configuration page is the heart of the application. Every supported llama.cpp flag is listed with:

- **Plain-English explanation** for beginners
- **Expert detail** in advanced mode (toggle in the header)
- **Performance / VRAM / latency / risk impact badges**
- **Recommended value** where applicable

### Sections

- **runtime** — `--threads`, `--ctx-size`, `--batch-size`, `--ubatch-size`, `--n-predict`
- **gpu** — `--gpu-layers`, `--main-gpu`, `--split-mode`, `--tensor-split`, `--flash-attn`
- **memory** — `--mlock`, `--no-mmap`, `--cache-type-k`, `--cache-type-v`
- **context** — `--rope-scaling` and friends
- **sampling** — `--temp`, `--top-k`, `--top-p`, `--repeat-penalty`, `--mirostat`, `--seed`

### Preview command

Click **Preview command** at the top to see the exact `llama-cli` argv that would be executed for the current configuration. The command is quoted for shell display but always invoked as an argv array (no `shell=True`), so model paths and extra args cannot inject shell metacharacters.

### Tips

- Beginner mode shows every parameter with a one-liner; advanced mode adds expert explanations.
- The model path field at the top is shared with the Playground and Benchmark pages.
- Setting `--gpu-layers` to a very large number (e.g. 999) tells llama.cpp to offload the entire model if it fits.
- If you enable Flash Attention with a quantized V cache (e.g. `q8_0`), make sure your llama.cpp build supports the combination.

---

## 3. Models

**Scan.** Click *Scan* to discover all `.gguf` files under your configured `models/` directory. LlamaForge reads each file's GGUF metadata to extract architecture, context length, parameter count, tokenizer, and quantization.

**Hugging Face download.** Enter a `repo_id` and `filename` (e.g. `TheBloke/Llama-2-7B-Chat-GGUF` and `llama-2-7b-chat.Q4_K_M.gguf`). The backend uses `huggingface_hub` to fetch directly into your models directory.

**Favorite.** Star models you use most — they show up first in pickers.

**Use.** Click *Use* on a row to load that path into the active configuration. From there it propagates to Playground, Benchmark, and Optimization.

---

## 4. Presets

Built-in presets are seeded on first run:

| Preset | Intent |
|--------|--------|
| **Maximum Speed** | Aggressive GPU offload, Flash Attention, batch=1024, q8 KV |
| **Balanced** | Default for most users |
| **Maximum Quality** | Larger context, full f16 KV, lower temperature |
| **Low Memory** | 4-6 GB VRAM systems; partial offload + q4 KV |
| **Jetson Stable** | Tuned for Jetson Orin Nano 8 GB shared memory |
| **TensorRT Optimized** | Companion settings for FP16 TensorRT-LLM engines |

You can also save your current configuration as a custom preset. Built-in presets cannot be deleted.

---

## 5. Benchmark

Click **Run benchmark** to measure your current configuration against a fixed prompt. LlamaForge captures:

- prompt-eval tokens/sec
- token-generation tokens/sec
- total wall time
- first-token latency
- peak / average VRAM (sampled at 2 Hz)
- average GPU utilisation
- peak temperature (and a *throttled* flag at 85 °C)
- average power draw (when available)

Every run is appended to `data/benchmarks.json`. The history table shows the most recent runs and the bar chart plots throughput.

### How it works

The service runs `llama-cli` as a subprocess and parses its `prompt eval time` / `eval time` lines on stderr. While the subprocess runs, a sampler polls `pynvml` every 500 ms for VRAM, GPU util, temperature, and power.

### Compare

Hit `POST /api/benchmark/compare` with a list of result IDs to receive a side-by-side payload (planned UI surface; data is already stored).

---

## 6. Optimization

Two engines live on this page:

### Auto quantization

Given your detected VRAM, a model size in billions of parameters, target quality, and Jetson-or-not, the heuristic engine picks a primary quantization and explains why. It also returns a full table comparing every supported quant on bits-per-weight, quality score, speed score, and estimated VRAM for a 7 B model.

The scoring rules are intentionally simple and inspectable in `backend/app/services/quantization_service.py`. They reward:

- biggest quant that fits with headroom (target = best)
- highest speed score (target = speed)
- balanced quality + speed (target = balanced)
- and apply a Jetson bonus to smaller, faster quants

### Config search

Selects 4–5 candidate configurations (full offload + flash attn, balanced, q8 KV, partial offload, Jetson-tuned) and runs a real benchmark on each. Results are scored against the chosen goal:

| Goal | Reward |
|------|--------|
| `fastest` | high tokens/sec, low latency |
| `lowest_memory` | low peak VRAM, some weight on tps |
| `most_stable` | low peak temperature |
| `best_quality` | tps × 0.3 minus latency penalty |
| `balanced` | tps minus VRAM and latency penalties |

Each candidate card shows its tps, VRAM, and temperature; click *Apply* to load it into the active config.

---

## 7. Playground

Streaming inference. The UI opens a WebSocket to `/api/inference/stream`, sends the active config + prompt, and renders tokens as they stream in. Live metrics tiles (tokens/sec estimate, VRAM, GPU util, token count) update every 0.5 s.

### Tips

- Use the **Active config** sidebar to confirm what you're actually running.
- *Stop* aborts the WebSocket; the backend kills the subprocess shortly after.
- The tokens/sec estimate is approximate (counted by spaces in the streamed output). The Benchmark page reports authoritative numbers parsed from llama.cpp's own timings.

---

## 8. TensorRT-LLM

LlamaForge is intentionally conservative about TensorRT-LLM:

- `GET /api/tensorrt/detect` reports whether `trtllm-build` and `trtllm-run` are on PATH.
- The build wizard generates the exact `trtllm-build` command for your target precision (FP16 / BF16 / INT8), max batch / input / output lengths, paged KV cache, and fused MLP.
- You then run that command in your own TensorRT-LLM environment (it's heavy and version-sensitive) and register the resulting engine path back in LlamaForge for tracking.

This separation lets the UI guide users without trying to host the TensorRT-LLM toolchain in-process. Future versions will add side-by-side benchmarks of the same prompt against llama.cpp and TensorRT-LLM.

---

## 9. Jetson tuning

The Jetson API (`/api/jetson/...`) wraps `nvpmodel`, `jetson_clocks`, and swap helpers. By default everything runs in **dry-run** mode — the API returns the command that *would* be executed but does not invoke it. Pass `apply: true` to actually run.

Use cases:

- **Power mode** — `nvpmodel -m <id>` to switch between MAXN / 15W / 7W modes.
- **jetson_clocks** — pin clocks to maximum for stable benchmarks.
- **Swap** — provision a swap file when models are larger than RAM.

Run sudo-required commands from a terminal until you've verified the dry-run output looks right, especially on production devices.

---

## 10. Settings

- **llama-cli / llama-server** binary paths — leave blank to auto-discover.
- **Default models dir** — overrides `data/settings.json` for scans.
- **Hugging Face token** — used by downloads of gated repos.
- **Advanced mode** — show expert explanations everywhere by default.

The Settings page also reports the detected llama.cpp binary and version so you can verify the install scripts succeeded.

---

## Architecture

```
┌──────────────────────┐         ┌────────────────────────────┐
│      React UI        │ HTTP +  │       FastAPI backend      │
│  Dashboard / Config  │ WS────▶ │  services / api / storage  │
│  Benchmark / etc.    │         │                            │
└──────────────────────┘         └─────────────┬──────────────┘
                                                │ subprocess
                                                ▼
                                      ┌──────────────────┐
                                      │    llama.cpp     │
                                      └──────────────────┘
                                                │
                                                ▼
                                          GGUF models
```

- All state is JSON files in `data/`. No database server is required.
- Hardware metrics come from `pynvml` (GPU), `psutil` (CPU/RAM/disk), and `jtop` (Jetson).
- Inference and benchmarking always invoke `llama-cli` as a subprocess with an argv array — never `shell=True`.

## Storage layout

| File | Purpose |
|------|---------|
| `data/settings.json` | Singleton — binary paths, theme, HF token |
| `data/hardware_latest.json` | Most recent hardware snapshot |
| `data/hardware_history.json` | Append-only snapshot history |
| `data/models.json` | Registered GGUF models |
| `data/presets.json` | Built-in + user presets |
| `data/benchmarks.json` | Benchmark history |
| `data/tensorrt_engines.json` | Registered TensorRT engines |

Files are written atomically (`tmp` + `os.replace`) and guarded by per-collection locks, so concurrent API requests can safely mutate the same collection.

## Security model

- Subprocess invocations always use argv arrays. No `shell=True`.
- User-supplied strings (model paths, tensor splits, extra args) are validated against an allowlist regex (`A–Z a–z 0–9 _ . / : \ - , = and space`) before being placed on the command line.
- Jetson privileged commands (`nvpmodel`, `jetson_clocks`, `mkswap`) require an explicit `apply: true` flag and otherwise return a dry-run plan.
- Hugging Face tokens, when set, are stored in `data/settings.json` — keep that file out of source control.

## API reference

A few representative endpoints:

| Method | Path | Purpose |
|--------|------|---------|
| GET | `/api/health` | Liveness |
| GET | `/api/hardware` | Fresh hardware snapshot |
| GET | `/api/hardware/latest` | Cached snapshot |
| WS | `/api/dashboard/live` | 1 Hz hardware stream |
| GET | `/api/config/parameters` | Full parameter catalog |
| POST | `/api/config/preview` | Preview the resulting `llama-cli` argv |
| GET | `/api/config/settings` | Read app settings |
| PUT | `/api/config/settings` | Update app settings |
| GET | `/api/models` | List models |
| POST | `/api/models/scan` | Rescan `models/` |
| POST | `/api/models/download` | Hugging Face download |
| GET | `/api/quantization` | Quantization table |
| POST | `/api/quantization/recommend` | Recommend a quant |
| POST | `/api/benchmark/start` | Run a benchmark |
| GET | `/api/benchmark/history` | Past benchmarks |
| POST | `/api/optimize/recommend` | Search configs against a goal |
| GET | `/api/presets` | List presets |
| POST | `/api/presets` | Create a custom preset |
| WS | `/api/inference/stream` | Streaming chat |
| GET | `/api/tensorrt/detect` | TensorRT-LLM detection |
| POST | `/api/tensorrt/plan-build` | Build wizard command |
| GET | `/api/jetson/status` | Jetson status |
| POST | `/api/jetson/jetson-clocks` | Apply (or dry-run) jetson_clocks |

Full interactive docs: http://localhost:8000/docs (FastAPI Swagger).

---

## Roadmap

Marked as TODO in the codebase:

- Full TensorRT-LLM build pipeline integration (currently command-only).
- ML-based recommendation system (currently heuristic).
- Multi-GPU split-tuning suggestions.
- Distributed benchmarking and remote device management.
- Ollama compatibility layer + OpenAI-compatible API server.
- LoRA management & fine-tuning UI.
