# LlamaForge

**Cross-platform configuration & optimization platform for [llama.cpp](https://github.com/ggml-org/llama.cpp), tuned for NVIDIA Jetson Orin Nano.**

LlamaForge is the "NVIDIA Control Panel for llama.cpp": it detects your hardware, recommends quantizations, benchmarks configurations, exposes every llama.cpp flag with plain-English explanations, and runs inference from a modern web UI.

## Highlights

- **Hardware detection** — GPU / CPU / RAM / NVMe / Jetson (JetPack, nvpmodel, jetson_clocks, TensorRT, cuDNN)
- **Full parameter catalog** — every major llama.cpp flag with beginner & expert descriptions, performance/VRAM/latency impact
- **Auto quantization recommendation** — picks Q2_K through FP16 based on VRAM, model size, context, quality target
- **Benchmark engine** — measures prompt-eval, token-gen, latency, VRAM, GPU util, temps; stores history; side-by-side compare
- **Optimization engine** — finds fastest / most-stable / lowest-memory / balanced configs via heuristic + benchmark scoring
- **Preset system** — Maximum Speed, Balanced, Maximum Quality, Low Memory, Jetson Stable, TensorRT Optimized; plus user presets
- **Inference playground** — streaming chat with live tokens/sec, VRAM, GPU util
- **Model manager** — GGUF scanning, metadata extraction, HuggingFace downloads, tagging, favorites
- **Jetson tuning** — jetson_clocks, nvpmodel, thermal/swap/hugepages/CPU affinity helpers
- **TensorRT-LLM integration** — engine build wizard + comparison vs llama.cpp
- **JSON-file storage** — no database server required; everything lives in `data/*.json`

## Stack

- **Backend** Python 3.12 · FastAPI · Pydantic · WebSockets · asyncio · pynvml · psutil · jetson-stats
- **Frontend** React · TypeScript · Vite · TailwindCSS · ShadCN-style primitives · Zustand · Recharts · Monaco
- **Storage** JSON files (no SQL server)
- **Packaging** Docker · PyInstaller · portable mode

## Quick start

### 1 — Install prerequisites

- Python 3.12+
- Node 20+
- A C++ toolchain for building llama.cpp (cmake, ninja, MSVC on Windows or gcc/clang on Linux)
- (Optional) CUDA Toolkit 12+ for GPU acceleration

### 2 — Build llama.cpp

```powershell
# Windows
.\scripts\install_llama_cpp.ps1
```

```bash
# Linux / Jetson
./scripts/install_llama_cpp.sh
```

These scripts clone [ggml-org/llama.cpp](https://github.com/ggml-org/llama.cpp) into `vendor/llama.cpp`, build it (CUDA on if available), and write the binary path into `data/settings.json`.

### 3 — Backend

```bash
cd backend
python -m venv .venv
. .venv/Scripts/activate    # Windows
# source .venv/bin/activate # Linux
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

### 4 — Frontend

```bash
cd frontend
npm install
npm run dev
```

Open http://localhost:5173.

### 5 — Docker (optional)

```bash
docker compose -f docker/docker-compose.yml up --build
```

## Project layout

```
backend/        FastAPI app, services, schemas, JSON storage
frontend/       React + Vite + Tailwind UI
scripts/        Install / build helpers (llama.cpp, Jetson tuning)
data/           Runtime JSON storage (presets, benchmarks, models, settings)
models/         Default GGUF model directory (gitignored)
vendor/         Built llama.cpp source tree (gitignored)
docker/         Dockerfiles + compose
docs/           Detailed documentation
```

## Documentation

See `docs/USER_GUIDE.md` for a full walkthrough of every feature.

## Status

This is an active scaffold. Most surfaces are functional; a few — TensorRT-LLM engine build, ML-based recommendation — are stubs with clearly marked TODOs.

## License

MIT
