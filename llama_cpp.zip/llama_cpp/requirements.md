# AI Agent Prompt — Build a Cross-Platform llama.cpp Configuration & Optimization Platform for NVIDIA Jetson Orin Nano

## Objective

Build a production-grade cross-platform application with a modern Web-based UI that helps users configure, optimize, benchmark, tune, and run `llama.cpp` models easily on:

* NVIDIA Jetson Orin Nano (Primary Target)
* Ubuntu Linux
* Windows
* Future extensibility for macOS/Linux ARM

The application must abstract the complexity of `llama.cpp` and expose all available runtime, inference, GPU, quantization, batching, memory, and optimization parameters in a beginner-friendly and expert-friendly way.

The system must intelligently detect hardware, benchmark performance, recommend optimal configurations, store history, and automatically select the best-performing settings.

The application should become the “NVIDIA Control Panel for llama.cpp”.

Use official documentation and source code from:

* https://github.com/ggml-org/llama.cpp

The platform should support:

* CUDA acceleration
* NVIDIA Jetson optimization
* TensorRT-LLM integration
* Auto quantization recommendations
* Benchmarking
* Runtime profiling
* GGUF model management
* Performance analytics
* Configuration presets
* One-click optimization

---

# Core Product Vision

The application should solve the following problems:

1. Users do not understand llama.cpp flags.
2. Users struggle to optimize Jetson devices.
3. Users do not know which quantization to use.
4. Users cannot easily benchmark performance.
5. Users do not know optimal GPU layer configurations.
6. Users do not understand memory usage tradeoffs.
7. There is no unified UI for inference optimization.
8. Users cannot compare configurations historically.
9. TensorRT-LLM setup is difficult.
10. CUDA optimization requires expertise.

The platform should automatically guide users toward:

* maximum tokens/sec
* lowest latency
* best quality/performance balance
* lowest VRAM usage
* safest stable configuration

---

# Required Tech Stack

## Backend

Use:

* Python 3.12+
* FastAPI
* Pydantic
* SQLAlchemy
* SQLite initially
* WebSocket support
* asyncio

Optional:

* Redis
* PostgreSQL

---

## Frontend

Use:

* React
* TypeScript
* Vite
* TailwindCSS
* ShadCN/UI
* Zustand
* Recharts
* Monaco Editor

The UI must feel:

* modern
* responsive
* beginner-friendly
* highly visual
* similar to NVIDIA tooling quality

---

# Primary Features

# 1. Hardware Detection Engine

The application must automatically detect:

## GPU Information

* GPU name
* CUDA version
* Tensor cores
* VRAM
* compute capability
* clocks
* temperatures
* power usage

## CPU Information

* cores
* threads
* NUMA
* architecture

## Memory

* total RAM
* free RAM
* swap
* memory bandwidth

## Storage

* available disk space
* NVMe detection
* SSD/HDD detection

## Jetson-Specific Detection

* JetPack version
* nvpmodel
* jetson_clocks status
* thermal mode
* power mode
* TensorRT version
* CUDA version
* cuDNN version

Use:

* pynvml
* psutil
* jetson-stats (`jtop`)
* subprocess commands

---

# 2. llama.cpp Configuration UI

Expose ALL major llama.cpp parameters.

Each parameter must include:

* name
* description
* recommended values
* performance impact
* VRAM impact
* latency impact
* beginner explanation
* advanced explanation

Examples:

## Runtime Parameters

* --threads
* --ctx-size
* --batch-size
* --ubatch-size
* --gpu-layers
* --flash-attn
* --mlock
* --no-mmap
* --rope-scaling
* --cache-type-k
* --cache-type-v
* --temp
* --top-k
* --top-p
* --repeat-penalty
* --mirostat
* --seed
* --n-predict
* --split-mode
* --tensor-split
* --main-gpu

## CUDA Parameters

* CUDA graphs
* Flash Attention
* cuBLAS
* Tensor cores
* GPU offloading

## TensorRT-LLM Parameters

* engine precision
* fp16
* int8
* kv-cache
* paged attention
* builder optimization profiles

---

# 3. Intelligent Optimization Engine

Build an optimization engine that automatically determines best settings.

The engine should:

* benchmark multiple combinations
* compare throughput
* compare latency
* compare VRAM usage
* compare thermal behavior
* compare power efficiency

The engine should output:

* fastest config
* most stable config
* lowest memory config
* best balanced config

Use:

* heuristic rules
* benchmark scoring
* optional ML-based recommendation system

---

# 4. Auto Quantization Recommendation Engine

The system must analyze:

* available VRAM
* model size
* context length
* expected throughput
* desired quality

Then recommend:

* Q2_K
* Q3_K_M
* Q4_K_M
* Q4_K_S
* Q5_K_M
* Q6_K
* Q8_0
* FP16

For each quantization show:

* expected memory usage
* expected quality
* expected speed
* recommended use case

Provide visual comparisons.

The recommendation engine must especially optimize for:

* Jetson Orin Nano 8GB
* Jetson Orin Nano Super
* low-memory edge AI systems

---

# 5. Benchmarking System

Create a complete benchmarking framework.

Benchmarks should measure:

* prompt processing speed
* token generation speed
* latency
* VRAM usage
* RAM usage
* GPU utilization
* temperatures
* throttling
* power consumption

Store historical benchmark results.

Allow:

* side-by-side comparisons
* charts
* exporting reports

---

# 6. Performance Database

Store:

* previous configurations
* benchmark results
* system metrics
* model metadata
* inference logs
* crash history

Enable:

* restore previous configurations
* compare historical runs
* auto-suggest best past config

---

# 7. TensorRT-LLM Integration

Integrate TensorRT-LLM support.

Features:

* model conversion
* engine building
* runtime execution
* benchmarking
* profile comparison against llama.cpp

Support:

* FP16
* INT8
* TensorRT engines
* paged KV cache
* CUDA graphs

Provide:

* UI wizard
* step-by-step setup
* troubleshooting

---

# 8. Model Management System

Support:

* GGUF model scanning
* metadata extraction
* HuggingFace model downloads
* model tagging
* favorites
* quantization metadata

Show:

* architecture
* quantization type
* context size
* tokenizer info
* estimated VRAM usage

---

# 9. Inference Playground

Provide:

* chat UI
* streaming inference
* parameter adjustment
* live metrics
* prompt templates

Display:

* tokens/sec
* latency
* GPU utilization
* VRAM usage

---

# 10. Preset System

Provide built-in presets:

* Maximum Speed
* Balanced
* Maximum Quality
* Low Memory
* Jetson Stable
* TensorRT Optimized

Users should save custom presets.

---

# 11. Advanced Jetson Optimization

Automatically detect and optionally apply:

* jetson_clocks
* power modes
* thermal optimizations
* swap optimization
* hugepages
* CPU affinity
* memory locking
* CUDA tuning

Warn users about:

* overheating
* instability
* memory exhaustion

---

# 12. Explainability Layer

Every setting must explain:

* what it does
* why it matters
* risks
* performance tradeoffs

Use:

* tooltips
* diagrams
* interactive help
* examples

The application should educate users.

---

# UI Requirements

## Dashboard

Show:

* GPU stats
* RAM usage
* current model
* tokens/sec
* temperatures
* benchmark summaries

---

## Configuration Panel

Use:

* grouped sections
* collapsible panels
* advanced mode
* beginner mode

---

## Benchmark Visualization

Use charts for:

* throughput
* latency
* VRAM
* thermals
* power

---

## Theme

Use:

* dark mode by default
* NVIDIA-inspired aesthetics
* green accents
* responsive layouts

---

# Backend Requirements

Create modular services:

## Services

* HardwareService
* BenchmarkService
* OptimizationService
* LlamaCppService
* TensorRTService
* QuantizationService
* ModelService
* MetricsService
* PresetService

---

# API Requirements

Create REST APIs and WebSocket APIs.

Examples:

## Hardware APIs

* GET /hardware

## Benchmark APIs

* POST /benchmark/start
* GET /benchmark/history

## Model APIs

* GET /models
* POST /models/download

## Optimization APIs

* POST /optimize/recommend

---

# Database Schema

Design normalized schemas for:

* models
* benchmarks
* presets
* hardware profiles
* configurations
* sessions

---

# Cross-Platform Requirements

Support:

* Ubuntu
* Windows

Use abstraction layers for:

* GPU detection
* process execution
* CUDA detection

---

# Packaging Requirements

Provide:

* Docker support
* standalone binaries
* desktop installer
* portable mode

Use:

* PyInstaller
* Docker
* Electron wrapper optional

---

# Security Requirements

Prevent:

* arbitrary command injection
* dangerous shell execution

Validate:

* model paths
* CLI flags
* file access

---

# Logging & Diagnostics

Implement:

* structured logging
* crash recovery
* debug mode
* diagnostics export

---

# Stretch Goals

## Future Features

* multi-node inference
* Ollama integration
* OpenAI-compatible API server
* LoRA management
* Fine-tuning UI
* distributed benchmarking
* remote device management

---

# Project Structure

Suggested structure:

backend/
frontend/
shared/
docs/
scripts/
benchmarks/
models/
configs/

---

# Development Standards

Requirements:

* type safety
* modular architecture
* SOLID principles
* test coverage
* linting
* CI/CD ready

Use:

* pytest
* eslint
* pre-commit
* GitHub Actions

---

# Expected Deliverables

The AI agent must generate:

1. Full backend implementation
2. Full frontend implementation
3. Database models
4. API routes
5. WebSocket streaming
6. Benchmarking engine
7. llama.cpp integration layer
8. TensorRT integration
9. Hardware detection layer
10. Quantization recommendation engine
11. Docker setup
12. Installation scripts
13. Documentation
14. Example configs
15. Unit tests

---

# Important Engineering Notes

## llama.cpp Integration

The application should:

* dynamically construct CLI commands
* validate flags
* support future llama.cpp versions
* parse logs and metrics

The app should not hardcode unsupported flags.

Instead:

* detect installed llama.cpp version
* dynamically load supported flags

---

# Jetson-Specific Optimization Guidance

The application should intelligently tune:

* GPU layers
* batch size
* context size
* flash attention
* CUDA graphs

Especially for:

* 8GB VRAM constraints
* thermal throttling
* shared memory architecture

---

# TensorRT-LLM Requirements

Support:

* conversion workflows
* engine caching
* performance comparison
* runtime switching

The UI should allow:

* comparing llama.cpp vs TensorRT-LLM

---

# Auto Recommendation Logic

The recommendation engine should prioritize:

## If user wants speed:

* aggressive GPU offload
* smaller quantization
* optimized batch size

## If user wants quality:

* larger quantization
* larger context
* balanced GPU layers

## If user wants low memory:

* lower quantization
* reduced context
* smaller batch

---

# Acceptance Criteria

The application is complete when:

* users can configure llama.cpp visually
* beginners understand every setting
* benchmark results are stored and compared
* Jetson optimization works automatically
* TensorRT-LLM works
* quantization recommendations work
* best-performing configs auto-select
* users can run inference from UI
* the platform works on Ubuntu and Windows

---

# Final Goal

Create the best open-source GUI optimization platform for llama.cpp and Jetson edge AI systems.

The product should feel:

* professional
* educational
* intelligent
* high-performance
* production-ready

It should become the standard GUI management platform for local LLM optimization on edge devices.

Create a detailed documentation on how to use each feature and explain each feature and its benefits
