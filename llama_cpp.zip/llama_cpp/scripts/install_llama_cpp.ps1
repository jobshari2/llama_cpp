# Clone & build llama.cpp on Windows. Detects CUDA automatically.
[CmdletBinding()]
param(
    [string]$Repo = "https://github.com/ggml-org/llama.cpp.git",
    [string]$Branch = "master",
    [switch]$ForceCpu
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$vendor = Join-Path $root "vendor"
$src = Join-Path $vendor "llama.cpp"
$build = Join-Path $src "build"
$dataDir = Join-Path $root "data"
New-Item -ItemType Directory -Force -Path $vendor, $dataDir | Out-Null

if (-not (Test-Path $src)) {
    Write-Host "Cloning $Repo into $src" -ForegroundColor Cyan
    git clone --branch $Branch $Repo $src
} else {
    Write-Host "Updating existing checkout" -ForegroundColor Cyan
    git -C $src fetch --all
    git -C $src checkout $Branch
    git -C $src pull --ff-only
}

$useCuda = $false
if (-not $ForceCpu) {
    if (Get-Command nvcc -ErrorAction SilentlyContinue) {
        $useCuda = $true
        Write-Host "CUDA detected — building with CUDA acceleration" -ForegroundColor Green
    } else {
        Write-Host "CUDA not detected — building CPU-only (use Visual Studio Developer prompt for MSVC)" -ForegroundColor Yellow
    }
}

if (Test-Path $build) { Remove-Item -Recurse -Force $build }
New-Item -ItemType Directory -Force -Path $build | Out-Null

$cmakeArgs = @($src, "-B", $build)
if ($useCuda) { $cmakeArgs += @("-DGGML_CUDA=ON") }
$cmakeArgs += @("-DCMAKE_BUILD_TYPE=Release")

Write-Host "Configuring: cmake $cmakeArgs" -ForegroundColor Cyan
& cmake @cmakeArgs

Write-Host "Building..." -ForegroundColor Cyan
& cmake --build $build --config Release --target llama-cli llama-server -j

# Find the built binary.
$candidates = @(
    Join-Path $build "bin\Release\llama-cli.exe",
    Join-Path $build "bin\llama-cli.exe",
    Join-Path $build "Release\llama-cli.exe"
)
$binary = $candidates | Where-Object { Test-Path $_ } | Select-Object -First 1

if (-not $binary) {
    Write-Error "Build finished but llama-cli.exe was not found in expected locations."
    exit 1
}

Write-Host "Built: $binary" -ForegroundColor Green
$settingsFile = Join-Path $dataDir "settings.json"
$settings = @{
    llama_cli_path = $binary
    llama_server_path = (Join-Path (Split-Path -Parent $binary) "llama-server.exe")
    theme = "dark"
    advanced_mode = $false
}
$settings | ConvertTo-Json | Set-Content -Encoding utf8 $settingsFile
Write-Host "Wrote $settingsFile" -ForegroundColor Green
