#!/usr/bin/env bash
# Clone & build llama.cpp on Linux / Jetson. Detects CUDA automatically.
set -euo pipefail

REPO="${REPO:-https://github.com/ggml-org/llama.cpp.git}"
BRANCH="${BRANCH:-master}"
FORCE_CPU="${FORCE_CPU:-0}"

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
VENDOR="$ROOT/vendor"
SRC="$VENDOR/llama.cpp"
BUILD="$SRC/build"
DATA="$ROOT/data"

mkdir -p "$VENDOR" "$DATA"

if [[ ! -d "$SRC" ]]; then
    echo "Cloning $REPO into $SRC"
    git clone --branch "$BRANCH" "$REPO" "$SRC"
else
    echo "Updating existing checkout"
    git -C "$SRC" fetch --all
    git -C "$SRC" checkout "$BRANCH"
    git -C "$SRC" pull --ff-only
fi

USE_CUDA=0
if [[ "$FORCE_CPU" != "1" ]] && command -v nvcc >/dev/null 2>&1; then
    USE_CUDA=1
    echo "CUDA detected — building with CUDA acceleration"
fi

# Detect Jetson
if [[ -f /etc/nv_tegra_release ]]; then
    echo "Jetson detected — enabling CUDA + native arch"
    USE_CUDA=1
fi

rm -rf "$BUILD"
mkdir -p "$BUILD"

CMAKE_ARGS=(-B "$BUILD" "$SRC" -DCMAKE_BUILD_TYPE=Release)
if [[ "$USE_CUDA" == "1" ]]; then
    CMAKE_ARGS+=(-DGGML_CUDA=ON)
    if [[ -f /etc/nv_tegra_release ]]; then
        # Orin = sm_87
        CMAKE_ARGS+=(-DCMAKE_CUDA_ARCHITECTURES=87)
    fi
fi

cmake "${CMAKE_ARGS[@]}"
cmake --build "$BUILD" --config Release --target llama-cli llama-server -j"$(nproc)"

BIN="$BUILD/bin/llama-cli"
[[ -x "$BIN" ]] || BIN="$BUILD/llama-cli"
[[ -x "$BIN" ]] || { echo "Build complete but llama-cli not found"; exit 1; }

SETTINGS_FILE="$DATA/settings.json"
cat > "$SETTINGS_FILE" <<EOF
{
  "llama_cli_path": "$BIN",
  "llama_server_path": "$(dirname "$BIN")/llama-server",
  "theme": "dark",
  "advanced_mode": false
}
EOF

echo "Built: $BIN"
echo "Wrote $SETTINGS_FILE"
