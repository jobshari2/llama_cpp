from fastapi.testclient import TestClient

from app.main import app


def test_health():
    client = TestClient(app)
    r = client.get("/api/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"


def test_parameters_listed():
    client = TestClient(app)
    r = client.get("/api/config/parameters")
    assert r.status_code == 200
    data = r.json()
    flags = {p["flag"] for p in data}
    assert {"--gpu-layers", "--ctx-size", "--flash-attn"}.issubset(flags)


def test_quantizations_listed():
    client = TestClient(app)
    r = client.get("/api/quantization")
    assert r.status_code == 200
    names = {q["name"] for q in r.json()}
    assert "Q4_K_M" in names
