from pathlib import Path

from app.storage.json_store import JsonStore


def test_insert_get_update_delete(tmp_path: Path):
    store = JsonStore(root=tmp_path)
    rec = store.insert("widgets", {"name": "alpha"})
    assert rec["id"]
    assert store.get("widgets", rec["id"])["name"] == "alpha"

    store.update("widgets", rec["id"], {"name": "beta"})
    assert store.get("widgets", rec["id"])["name"] == "beta"

    assert store.delete("widgets", rec["id"]) is True
    assert store.get("widgets", rec["id"]) is None


def test_singleton_round_trip(tmp_path: Path):
    store = JsonStore(root=tmp_path)
    assert store.get_singleton("settings") == {}
    store.set_singleton("settings", {"theme": "dark"})
    assert store.get_singleton("settings")["theme"] == "dark"


def test_upsert_many(tmp_path: Path):
    store = JsonStore(root=tmp_path)
    store.upsert_many("models", [{"id": "x", "name": "a"}, {"id": "y", "name": "b"}])
    store.upsert_many("models", [{"id": "x", "name": "A"}])
    items = {it["id"]: it["name"] for it in store.list("models")}
    assert items == {"x": "A", "y": "b"}
