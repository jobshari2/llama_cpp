from app.services.quantization_service import QuantizationService


def test_recommend_for_8gb_jetson_picks_4bit_or_smaller():
    svc = QuantizationService()
    rec = svc.recommend(available_vram_mb=7000, params_b=7.0, ctx_size=4096, target="balanced", is_jetson=True)
    assert rec.primary in {"Q3_K_M", "Q4_K_S", "Q4_K_M"}
    assert rec.estimated_vram_mb is not None
    assert rec.estimated_vram_mb <= 7000


def test_recommend_for_24gb_picks_higher_quality():
    svc = QuantizationService()
    rec = svc.recommend(available_vram_mb=24000, params_b=7.0, ctx_size=4096, target="best", is_jetson=False)
    assert rec.primary in {"Q5_K_M", "Q6_K", "Q8_0", "FP16"}


def test_table_includes_all_quants():
    rec = QuantizationService().recommend(available_vram_mb=8000, params_b=7.0)
    names = {q.name for q in rec.table}
    assert {"Q4_K_M", "Q5_K_M", "Q6_K", "Q8_0", "FP16"}.issubset(names)
