import pytest

from app.schemas import LlamaConfig
from app.utils.command_builder import UnsafeArgument, build_llama_cli_command


def cfg(**overrides) -> LlamaConfig:
    base = LlamaConfig(model_path="/models/m.gguf").model_dump()
    base.update(overrides)
    return LlamaConfig(**base)


def test_minimal_command_contains_model_and_threads():
    cmd = build_llama_cli_command("/usr/bin/llama-cli", cfg())
    assert cmd[0] == "/usr/bin/llama-cli"
    assert "-m" in cmd and "/models/m.gguf" in cmd
    assert "-t" in cmd
    assert "--no-warmup" in cmd


def test_flash_attention_flag_present_only_when_enabled():
    on = build_llama_cli_command("llama-cli", cfg(flash_attn=True))
    off = build_llama_cli_command("llama-cli", cfg(flash_attn=False))
    assert "-fa" in on
    assert "-fa" not in off


def test_quantized_kv_cache_emitted():
    cmd = build_llama_cli_command("llama-cli", cfg(cache_type_k="q8_0", cache_type_v="q4_0"))
    assert "-ctk" in cmd and "q8_0" in cmd
    assert "-ctv" in cmd and "q4_0" in cmd


def test_unsafe_model_path_rejected():
    with pytest.raises(UnsafeArgument):
        build_llama_cli_command("llama-cli", cfg(model_path="/tmp/x; rm -rf /"))


def test_unsafe_extra_arg_rejected():
    bad = cfg()
    bad.extra_args = ["$(reboot)"]
    with pytest.raises(UnsafeArgument):
        build_llama_cli_command("llama-cli", bad)


def test_seed_only_when_set():
    has = build_llama_cli_command("llama-cli", cfg(seed=42))
    none = build_llama_cli_command("llama-cli", cfg(seed=-1))
    assert "--seed" in has and "42" in has
    assert "--seed" not in none
