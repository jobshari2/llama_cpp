"""Runtime configuration."""
from __future__ import annotations

from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict


REPO_ROOT = Path(__file__).resolve().parents[2]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="LLAMAFORGE_", env_file=".env", extra="ignore")

    data_dir: Path = REPO_ROOT / "data"
    models_dir: Path = REPO_ROOT / "models"
    vendor_dir: Path = REPO_ROOT / "vendor"
    llama_cpp_root: Path = REPO_ROOT / "vendor" / "llama.cpp"

    cors_origins: list[str] = ["http://localhost:5173", "http://localhost:3000"]
    host: str = "0.0.0.0"
    port: int = 8000

    def ensure_dirs(self) -> None:
        for p in (self.data_dir, self.models_dir, self.vendor_dir):
            p.mkdir(parents=True, exist_ok=True)


settings = Settings()
settings.ensure_dirs()
