"""Build llama.cpp CLI commands safely from a typed config.

Refuses to construct commands containing shell metacharacters in user-supplied
fields (model_path, tensor_split, extra_args). The caller invokes the resulting
list directly via subprocess without `shell=True`.
"""
from __future__ import annotations

import re
import shlex
from pathlib import Path
from typing import Iterable

from app.schemas import LlamaConfig


_SAFE_RE = re.compile(r"^[A-Za-z0-9_./:\\\- ,=]+$")


class UnsafeArgument(ValueError):
    pass


def _check_safe(value: str, label: str) -> str:
    if not _SAFE_RE.match(value):
        raise UnsafeArgument(f"Refusing unsafe characters in {label}: {value!r}")
    return value


def build_llama_cli_command(
    binary: str | Path,
    cfg: LlamaConfig,
    *,
    prompt: str | None = None,
    extra: Iterable[str] | None = None,
) -> list[str]:
    """Produce an argv array for `llama-cli` from a LlamaConfig."""
    cmd: list[str] = [str(binary), "-m", _check_safe(cfg.model_path, "model_path")]
    cmd += ["-t", str(cfg.threads)]
    cmd += ["-c", str(cfg.ctx_size)]
    cmd += ["-b", str(cfg.batch_size)]
    cmd += ["-ub", str(cfg.ubatch_size)]
    cmd += ["-n", str(cfg.n_predict)]
    cmd += ["-ngl", str(cfg.gpu_layers)]
    if cfg.main_gpu:
        cmd += ["--main-gpu", str(cfg.main_gpu)]
    if cfg.split_mode:
        cmd += ["--split-mode", cfg.split_mode]
    if cfg.tensor_split:
        cmd += ["--tensor-split", _check_safe(cfg.tensor_split, "tensor_split")]
    if cfg.flash_attn:
        cmd += ["-fa"]
    if cfg.mlock:
        cmd += ["--mlock"]
    if cfg.no_mmap:
        cmd += ["--no-mmap"]
    if cfg.cache_type_k:
        cmd += ["-ctk", cfg.cache_type_k]
    if cfg.cache_type_v:
        cmd += ["-ctv", cfg.cache_type_v]
    if cfg.rope_scaling and cfg.rope_scaling != "none":
        cmd += ["--rope-scaling", cfg.rope_scaling]
    if cfg.rope_freq_base is not None:
        cmd += ["--rope-freq-base", str(cfg.rope_freq_base)]
    if cfg.rope_freq_scale is not None:
        cmd += ["--rope-freq-scale", str(cfg.rope_freq_scale)]
    cmd += ["--temp", str(cfg.temperature)]
    cmd += ["--top-k", str(cfg.top_k)]
    cmd += ["--top-p", str(cfg.top_p)]
    cmd += ["--repeat-penalty", str(cfg.repeat_penalty)]
    if cfg.mirostat:
        cmd += ["--mirostat", str(cfg.mirostat)]
    if cfg.seed != -1:
        cmd += ["--seed", str(cfg.seed)]
    for a in cfg.extra_args:
        cmd.append(_check_safe(a, "extra_args"))
    if extra:
        for a in extra:
            cmd.append(_check_safe(a, "extra"))
    if prompt is not None:
        cmd += ["-p", prompt]
    cmd.append("--no-warmup")
    return cmd


def quote_for_display(cmd: list[str]) -> str:
    """Return a copy-pasteable representation of an argv list."""
    return " ".join(shlex.quote(a) for a in cmd)
