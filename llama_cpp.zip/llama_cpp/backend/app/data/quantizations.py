"""GGUF quantization metadata."""
from __future__ import annotations

from app.schemas import QuantInfo


QUANTIZATIONS: list[QuantInfo] = [
    QuantInfo(name="Q2_K", bits_per_weight=2.6, quality=2, speed=10,
              expected_vram_mb_for_7b=2900,
              description="Smallest, lowest quality 2-bit K-quant. Major quality drop on most models.",
              use_case="Tiny edge devices where any other quant won't fit."),
    QuantInfo(name="Q3_K_M", bits_per_weight=3.9, quality=4, speed=9,
              expected_vram_mb_for_7b=3800,
              description="3-bit medium K-quant. Decent quality at very low memory.",
              use_case="Jetson Orin Nano 4GB; experimentation."),
    QuantInfo(name="Q4_K_S", bits_per_weight=4.6, quality=6, speed=9,
              expected_vram_mb_for_7b=4200,
              description="4-bit small K-quant. Slightly faster, slightly lower quality than Q4_K_M.",
              use_case="Jetson Orin Nano 8GB / RTX 30-series mid-tier."),
    QuantInfo(name="Q4_K_M", bits_per_weight=4.85, quality=7, speed=8,
              expected_vram_mb_for_7b=4400,
              description="4-bit medium K-quant. Excellent quality / size tradeoff.",
              use_case="Default recommendation for 8GB devices."),
    QuantInfo(name="Q5_K_M", bits_per_weight=5.7, quality=8, speed=7,
              expected_vram_mb_for_7b=5100,
              description="5-bit medium K-quant. Near full-precision quality.",
              use_case="12GB+ GPUs; quality-sensitive workloads."),
    QuantInfo(name="Q6_K", bits_per_weight=6.6, quality=9, speed=6,
              expected_vram_mb_for_7b=5800,
              description="6-bit K-quant. Almost indistinguishable from FP16.",
              use_case="16GB GPUs; production inference."),
    QuantInfo(name="Q8_0", bits_per_weight=8.5, quality=10, speed=5,
              expected_vram_mb_for_7b=7400,
              description="8-bit, near lossless.",
              use_case="High-end GPUs; ground truth comparisons."),
    QuantInfo(name="FP16", bits_per_weight=16.0, quality=10, speed=4,
              expected_vram_mb_for_7b=14_000,
              description="Half precision floating point. Reference quality.",
              use_case="A100 / H100 / RTX 4090."),
]


def by_name(name: str) -> QuantInfo | None:
    for q in QUANTIZATIONS:
        if q.name == name:
            return q
    return None
