"""Catalog of llama.cpp parameters with rich metadata.

This is the single source of truth for the Configuration UI. Each entry maps a
CLI flag to a description, value range, defaults, and impact estimates.
"""
from __future__ import annotations

from app.schemas import ParamMeta


PARAMETERS: list[ParamMeta] = [
    # ---------- Runtime / threading ----------
    ParamMeta(
        flag="--threads", name="CPU threads", category="runtime", type="int",
        default=4, minimum=1, maximum=128, recommended="physical_cores",
        beginner="How many CPU cores llama.cpp uses for inference.",
        advanced="Set to the number of physical (not logical) cores. SMT/Hyper-threading rarely helps; on Jetson use all 6/8 cores.",
        perf_impact="high", vram_impact="none", latency_impact="medium", risk="none",
    ),
    ParamMeta(
        flag="--ctx-size", name="Context size", category="runtime", type="int",
        default=4096, minimum=128, maximum=131072, recommended=4096,
        beginner="Maximum number of tokens the model can see at once (input + output).",
        advanced="Memory for the KV cache scales linearly with this. Larger context = much more VRAM.",
        perf_impact="medium", vram_impact="high", latency_impact="medium", risk="medium",
    ),
    ParamMeta(
        flag="--batch-size", name="Batch size (logical)", category="runtime", type="int",
        default=512, minimum=1, maximum=4096, recommended=512,
        beginner="How many prompt tokens to evaluate per batch.",
        advanced="Larger batches improve prompt processing throughput but use more VRAM.",
        perf_impact="medium", vram_impact="medium", latency_impact="low",
    ),
    ParamMeta(
        flag="--ubatch-size", name="Micro-batch size (physical)", category="runtime", type="int",
        default=512, minimum=1, maximum=4096, recommended=512,
        beginner="Physical micro-batch fed to the GPU at once.",
        advanced="Should usually match --batch-size; smaller values reduce peak VRAM at the cost of speed.",
        perf_impact="medium", vram_impact="medium", latency_impact="low",
    ),
    ParamMeta(
        flag="--n-predict", name="Max tokens to generate", category="runtime", type="int",
        default=256, minimum=-1, maximum=8192, recommended=256,
        beginner="Maximum number of tokens to generate. -1 = unlimited.",
        advanced="Affects total wall time but not throughput.",
        perf_impact="none", vram_impact="none", latency_impact="high",
    ),
    # ---------- GPU offload ----------
    ParamMeta(
        flag="--gpu-layers", name="GPU layers", category="gpu", type="int",
        default=0, minimum=0, maximum=999, recommended="auto",
        beginner="Number of model layers offloaded to the GPU. Higher = faster but uses more VRAM.",
        advanced="Set to a very large number (e.g. 999) to offload everything if it fits. On Jetson, balance against shared memory.",
        perf_impact="high", vram_impact="high", latency_impact="high", risk="medium",
    ),
    ParamMeta(
        flag="--main-gpu", name="Main GPU index", category="gpu", type="int",
        default=0, minimum=0, maximum=15,
        beginner="Which GPU to use as the primary device.",
        advanced="In multi-GPU setups, this device hosts the KV cache when split-mode is 'layer'.",
        perf_impact="low", vram_impact="none", latency_impact="none",
    ),
    ParamMeta(
        flag="--split-mode", name="Multi-GPU split mode", category="gpu", type="enum",
        default="layer", enum=["none", "layer", "row"],
        beginner="How to split work across multiple GPUs.",
        advanced="'layer' splits whole layers across GPUs (recommended); 'row' splits within tensors and increases interconnect traffic.",
        perf_impact="medium", vram_impact="none", latency_impact="medium",
    ),
    ParamMeta(
        flag="--tensor-split", name="Tensor split ratios", category="gpu", type="string",
        beginner="How to share the model across multiple GPUs (e.g. '0.6,0.4').",
        advanced="Comma-separated weights per GPU. Useful when GPUs differ in VRAM.",
        perf_impact="low", vram_impact="medium", latency_impact="low",
    ),
    ParamMeta(
        flag="--flash-attn", name="Flash Attention", category="gpu", type="bool",
        default=False, recommended=True,
        beginner="Enables a fast attention kernel — major speedup on supported GPUs.",
        advanced="Requires recent CUDA + compute capability >= 7.0. Combine with quantized KV cache for big wins.",
        perf_impact="high", vram_impact="low", latency_impact="medium",
    ),
    # ---------- Memory ----------
    ParamMeta(
        flag="--mlock", name="Lock model in RAM", category="memory", type="bool",
        default=False,
        beginner="Pin the model in physical RAM to avoid swap-out.",
        advanced="Avoid on systems with limited RAM. Helpful on production servers with abundant memory.",
        perf_impact="low", vram_impact="none", latency_impact="low", risk="medium",
    ),
    ParamMeta(
        flag="--no-mmap", name="Disable mmap", category="memory", type="bool",
        default=False,
        beginner="Load the entire model into RAM instead of memory-mapping the file.",
        advanced="Slower startup, higher memory pressure, but slightly faster sustained throughput on some systems.",
        perf_impact="low", vram_impact="none", latency_impact="low", risk="medium",
    ),
    ParamMeta(
        flag="--cache-type-k", name="KV cache type (K)", category="memory", type="enum",
        default="f16", enum=["f32", "f16", "q8_0", "q4_0"],
        beginner="Precision of the K (key) cache. Lower precision saves VRAM.",
        advanced="q8_0 is nearly lossless. q4_0 saves more VRAM but degrades quality slightly.",
        perf_impact="medium", vram_impact="high", latency_impact="low",
    ),
    ParamMeta(
        flag="--cache-type-v", name="KV cache type (V)", category="memory", type="enum",
        default="f16", enum=["f32", "f16", "q8_0", "q4_0"],
        beginner="Precision of the V (value) cache.",
        advanced="Match cache-type-k. Requires Flash Attention for non-f16 V cache.",
        perf_impact="medium", vram_impact="high", latency_impact="low",
    ),
    # ---------- Rope ----------
    ParamMeta(
        flag="--rope-scaling", name="RoPE scaling", category="context", type="enum",
        enum=["none", "linear", "yarn"], default="none",
        beginner="Method to extend the context window beyond the model's training length.",
        advanced="'yarn' is the highest quality long-context method. Combine with rope-freq-scale.",
        perf_impact="none", vram_impact="none", latency_impact="none", risk="medium",
    ),
    # ---------- Sampling ----------
    ParamMeta(
        flag="--temp", name="Temperature", category="sampling", type="float",
        default=0.8, minimum=0.0, maximum=2.0,
        beginner="Higher = more creative; lower = more focused. 0 = greedy.",
        advanced="Sampling occurs after top-k/top-p filtering. Set 0 with greedy decoding for reproducible outputs.",
        perf_impact="none", vram_impact="none", latency_impact="none",
    ),
    ParamMeta(
        flag="--top-k", name="Top-K", category="sampling", type="int",
        default=40, minimum=0, maximum=1000,
        beginner="Keep only the K most likely next tokens.",
        advanced="40 is a good default. 0 disables top-k.",
        perf_impact="none", vram_impact="none", latency_impact="none",
    ),
    ParamMeta(
        flag="--top-p", name="Top-P", category="sampling", type="float",
        default=0.95, minimum=0.0, maximum=1.0,
        beginner="Keep tokens whose cumulative probability is below P.",
        advanced="Common value 0.9-0.95.",
        perf_impact="none", vram_impact="none", latency_impact="none",
    ),
    ParamMeta(
        flag="--repeat-penalty", name="Repeat penalty", category="sampling", type="float",
        default=1.1, minimum=0.5, maximum=2.0,
        beginner="Discourage repeating tokens.",
        advanced="Above 1.3 can hurt fluency.",
        perf_impact="none", vram_impact="none", latency_impact="none",
    ),
    ParamMeta(
        flag="--mirostat", name="Mirostat", category="sampling", type="enum",
        enum=["0", "1", "2"], default="0",
        beginner="Adaptive sampling that targets a fixed perplexity.",
        advanced="2 is recommended where supported. Replaces top-k / top-p.",
        perf_impact="none", vram_impact="none", latency_impact="none",
    ),
    ParamMeta(
        flag="--seed", name="Seed", category="sampling", type="int",
        default=-1, minimum=-1, maximum=2_147_483_647,
        beginner="Random seed. -1 = pick a random seed.",
        advanced="Set a fixed seed for reproducible outputs.",
        perf_impact="none", vram_impact="none", latency_impact="none",
    ),
]


def by_flag(flag: str) -> ParamMeta | None:
    for p in PARAMETERS:
        if p.flag == flag:
            return p
    return None


def by_category() -> dict[str, list[ParamMeta]]:
    out: dict[str, list[ParamMeta]] = {}
    for p in PARAMETERS:
        out.setdefault(p.category, []).append(p)
    return out
