"""Built-in presets seeded into the JSON store on first run."""
from __future__ import annotations

from app.schemas import LlamaConfig, PresetCreate


def _cfg(**overrides) -> LlamaConfig:
    base = LlamaConfig(model_path="").model_dump()
    base.update(overrides)
    return LlamaConfig(**base)


BUILTIN_PRESETS: list[PresetCreate] = [
    PresetCreate(
        name="Maximum Speed",
        description="Aggressive GPU offload, Flash Attention, larger batch — pure throughput.",
        tags=["speed", "throughput"],
        builtin=True,
        icon="Zap",
        config=_cfg(gpu_layers=999, flash_attn=True, batch_size=1024, ubatch_size=1024,
                    cache_type_k="q8_0", cache_type_v="q8_0", ctx_size=4096),
    ),
    PresetCreate(
        name="Balanced",
        description="Good speed and quality on most GPUs.",
        tags=["balanced", "default"],
        builtin=True,
        icon="Sliders",
        config=_cfg(gpu_layers=999, flash_attn=True, batch_size=512, ubatch_size=512,
                    cache_type_k="f16", cache_type_v="f16", ctx_size=4096),
    ),
    PresetCreate(
        name="Maximum Quality",
        description="Larger context, full f16 KV cache, conservative sampling.",
        tags=["quality"],
        builtin=True,
        icon="Sparkles",
        config=_cfg(gpu_layers=999, flash_attn=True, batch_size=512, ubatch_size=512,
                    cache_type_k="f16", cache_type_v="f16", ctx_size=8192,
                    temperature=0.7, top_p=0.9),
    ),
    PresetCreate(
        name="Low Memory",
        description="Reduced context, quantized KV cache, small batch — fits in 4-6 GB VRAM.",
        tags=["memory", "edge"],
        builtin=True,
        icon="HardDrive",
        config=_cfg(gpu_layers=20, flash_attn=True, batch_size=256, ubatch_size=256,
                    cache_type_k="q4_0", cache_type_v="q4_0", ctx_size=2048),
    ),
    PresetCreate(
        name="Jetson Stable",
        description="Tuned for NVIDIA Jetson Orin Nano 8GB shared memory.",
        tags=["jetson", "edge", "stable"],
        builtin=True,
        icon="Cpu",
        config=_cfg(gpu_layers=99, flash_attn=True, batch_size=128, ubatch_size=128,
                    cache_type_k="q8_0", cache_type_v="q8_0", ctx_size=2048,
                    threads=6, mlock=False),
    ),
    PresetCreate(
        name="TensorRT Optimized",
        description="Configuration paired with a TensorRT-LLM engine (FP16, paged KV).",
        tags=["tensorrt", "speed"],
        builtin=True,
        icon="Rocket",
        config=_cfg(gpu_layers=999, flash_attn=True, batch_size=1024, ubatch_size=1024,
                    cache_type_k="f16", cache_type_v="f16", ctx_size=4096),
    ),
]
