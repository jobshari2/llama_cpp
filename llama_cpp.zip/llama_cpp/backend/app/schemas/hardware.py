from __future__ import annotations

from typing import Optional
from pydantic import BaseModel, Field


class GpuInfo(BaseModel):
    index: int
    name: str
    vram_total_mb: int
    vram_free_mb: int
    vram_used_mb: int
    cuda_version: Optional[str] = None
    driver_version: Optional[str] = None
    compute_capability: Optional[str] = None
    tensor_cores: Optional[bool] = None
    sm_clock_mhz: Optional[int] = None
    mem_clock_mhz: Optional[int] = None
    temperature_c: Optional[float] = None
    power_w: Optional[float] = None
    utilization_percent: Optional[float] = None


class CpuInfo(BaseModel):
    physical_cores: int
    logical_cores: int
    architecture: str
    model: Optional[str] = None
    base_freq_mhz: Optional[float] = None
    current_freq_mhz: Optional[float] = None
    numa_nodes: Optional[int] = None
    load_percent: Optional[float] = None


class MemoryInfo(BaseModel):
    total_mb: int
    free_mb: int
    used_mb: int
    swap_total_mb: int
    swap_free_mb: int
    bandwidth_gb_s: Optional[float] = None


class StorageDevice(BaseModel):
    mount: str
    fstype: Optional[str] = None
    total_gb: float
    free_gb: float
    is_nvme: Optional[bool] = None
    is_ssd: Optional[bool] = None


class StorageInfo(BaseModel):
    devices: list[StorageDevice] = Field(default_factory=list)


class JetsonInfo(BaseModel):
    is_jetson: bool = False
    model: Optional[str] = None
    jetpack_version: Optional[str] = None
    nvpmodel: Optional[str] = None
    jetson_clocks_active: Optional[bool] = None
    thermal_mode: Optional[str] = None
    power_mode: Optional[str] = None
    tensorrt_version: Optional[str] = None
    cuda_version: Optional[str] = None
    cudnn_version: Optional[str] = None


class HardwareSnapshot(BaseModel):
    platform: str
    os: str
    hostname: str
    gpus: list[GpuInfo] = Field(default_factory=list)
    cpu: CpuInfo
    memory: MemoryInfo
    storage: StorageInfo
    jetson: JetsonInfo = Field(default_factory=JetsonInfo)
    captured_at: str
