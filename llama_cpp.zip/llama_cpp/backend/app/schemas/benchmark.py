from __future__ import annotations

from typing import Optional
from pydantic import BaseModel, Field

from .config import LlamaConfig


class BenchmarkRequest(BaseModel):
    config: LlamaConfig
    prompt: str = "The quick brown fox jumps over the lazy dog. " * 8
    n_predict: int = 128
    runs: int = 1
    label: Optional[str] = None


class BenchmarkResult(BaseModel):
    id: Optional[str] = None
    label: Optional[str] = None
    config: LlamaConfig
    prompt_tokens: int = 0
    generated_tokens: int = 0
    prompt_eval_tps: float = 0.0
    token_gen_tps: float = 0.0
    total_seconds: float = 0.0
    latency_first_token_ms: Optional[float] = None
    peak_vram_mb: Optional[float] = None
    avg_vram_mb: Optional[float] = None
    peak_ram_mb: Optional[float] = None
    avg_gpu_utilization: Optional[float] = None
    peak_temperature_c: Optional[float] = None
    throttled: bool = False
    avg_power_w: Optional[float] = None
    success: bool = True
    error: Optional[str] = None
    log_excerpt: Optional[str] = None
    hardware_id: Optional[str] = None
    created_at: Optional[str] = None


class BenchmarkComparison(BaseModel):
    ids: list[str]
    results: list[BenchmarkResult] = Field(default_factory=list)
