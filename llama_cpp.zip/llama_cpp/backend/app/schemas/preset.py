from __future__ import annotations

from typing import Optional
from pydantic import BaseModel, Field

from .config import LlamaConfig


class PresetCreate(BaseModel):
    name: str
    description: str = ""
    tags: list[str] = Field(default_factory=list)
    config: LlamaConfig
    builtin: bool = False
    icon: Optional[str] = None


class Preset(PresetCreate):
    id: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
