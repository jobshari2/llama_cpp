from __future__ import annotations

from typing import Optional
from pydantic import BaseModel, Field


class ModelRecord(BaseModel):
    id: Optional[str] = None
    name: str
    path: str
    size_bytes: int = 0
    architecture: Optional[str] = None
    quantization: Optional[str] = None
    context_length: Optional[int] = None
    parameter_count: Optional[int] = None
    tokenizer: Optional[str] = None
    estimated_vram_mb: Optional[int] = None
    favorite: bool = False
    tags: list[str] = Field(default_factory=list)
    source: Optional[str] = None
    sha256: Optional[str] = None


class ModelDownloadRequest(BaseModel):
    repo_id: str
    filename: str
    revision: Optional[str] = "main"
