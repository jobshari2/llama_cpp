from __future__ import annotations

from typing import Any, Literal, Optional
from pydantic import BaseModel, Field


class LlamaConfig(BaseModel):
    """Subset of llama.cpp runtime parameters represented as a typed config."""

    model_path: str
    threads: int = 4
    ctx_size: int = 4096
    batch_size: int = 512
    ubatch_size: int = 512
    n_predict: int = 256
    gpu_layers: int = 0
    main_gpu: int = 0
    split_mode: Literal["none", "layer", "row"] = "layer"
    tensor_split: Optional[str] = None
    flash_attn: bool = False
    mlock: bool = False
    no_mmap: bool = False
    cache_type_k: Literal["f32", "f16", "q8_0", "q4_0"] = "f16"
    cache_type_v: Literal["f32", "f16", "q8_0", "q4_0"] = "f16"
    rope_scaling: Optional[Literal["none", "linear", "yarn"]] = None
    rope_freq_base: Optional[float] = None
    rope_freq_scale: Optional[float] = None
    temperature: float = 0.8
    top_k: int = 40
    top_p: float = 0.95
    repeat_penalty: float = 1.1
    mirostat: int = 0
    seed: int = -1
    extra_args: list[str] = Field(default_factory=list)


class ParamMeta(BaseModel):
    flag: str
    name: str
    category: str
    type: Literal["int", "float", "bool", "string", "enum"]
    default: Any = None
    minimum: Optional[float] = None
    maximum: Optional[float] = None
    enum: Optional[list[str]] = None
    recommended: Optional[Any] = None
    beginner: str
    advanced: str
    perf_impact: Literal["none", "low", "medium", "high"] = "low"
    vram_impact: Literal["none", "low", "medium", "high"] = "none"
    latency_impact: Literal["none", "low", "medium", "high"] = "none"
    risk: Literal["none", "low", "medium", "high"] = "none"


class AppSettings(BaseModel):
    llama_cli_path: Optional[str] = None
    llama_server_path: Optional[str] = None
    default_models_dir: Optional[str] = None
    huggingface_token: Optional[str] = None
    theme: Literal["dark", "light"] = "dark"
    advanced_mode: bool = False
