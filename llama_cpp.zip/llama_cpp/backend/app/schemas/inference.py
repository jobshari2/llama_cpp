from __future__ import annotations

from pydantic import BaseModel

from .config import LlamaConfig


class InferenceRequest(BaseModel):
    config: LlamaConfig
    prompt: str
    stream: bool = True
