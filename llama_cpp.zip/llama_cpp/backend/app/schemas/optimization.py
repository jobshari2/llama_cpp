from __future__ import annotations

from typing import Literal, Optional
from pydantic import BaseModel, Field

from .config import LlamaConfig
from .benchmark import BenchmarkResult


OptimizationGoal = Literal["fastest", "balanced", "lowest_memory", "most_stable", "best_quality"]


class OptimizeRequest(BaseModel):
    model_path: str
    goal: OptimizationGoal = "balanced"
    max_runs: int = 4
    max_seconds_per_run: int = 60
    starting_config: Optional[LlamaConfig] = None


class OptimizationCandidate(BaseModel):
    config: LlamaConfig
    score: float
    rationale: str
    benchmark: Optional[BenchmarkResult] = None


class OptimizeResponse(BaseModel):
    goal: OptimizationGoal
    fastest: Optional[OptimizationCandidate] = None
    balanced: Optional[OptimizationCandidate] = None
    lowest_memory: Optional[OptimizationCandidate] = None
    most_stable: Optional[OptimizationCandidate] = None
    candidates: list[OptimizationCandidate] = Field(default_factory=list)
