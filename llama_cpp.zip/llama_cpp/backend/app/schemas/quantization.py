from __future__ import annotations

from typing import Optional
from pydantic import BaseModel, Field


class QuantInfo(BaseModel):
    name: str
    bits_per_weight: float
    quality: int
    speed: int
    expected_vram_mb_for_7b: int
    description: str
    use_case: str


class QuantizationRecommendation(BaseModel):
    primary: str
    alternatives: list[str] = Field(default_factory=list)
    reasoning: str
    estimated_vram_mb: Optional[int] = None
    quality_score: Optional[int] = None
    speed_score: Optional[int] = None
    table: list[QuantInfo] = Field(default_factory=list)
