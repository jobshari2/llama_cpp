"""Preset management. Built-in presets are seeded on first run."""
from __future__ import annotations

from app.data.presets import BUILTIN_PRESETS
from app.schemas import Preset, PresetCreate
from app.storage import store


class PresetService:
    COLLECTION = "presets"

    def __init__(self) -> None:
        self.ensure_seeded()

    def ensure_seeded(self) -> None:
        existing = {p.get("name") for p in store.list(self.COLLECTION)}
        for p in BUILTIN_PRESETS:
            if p.name not in existing:
                store.insert(self.COLLECTION, p.model_dump())

    def list(self) -> list[Preset]:
        return [Preset(**p) for p in store.list(self.COLLECTION)]

    def get(self, preset_id: str) -> Preset | None:
        rec = store.get(self.COLLECTION, preset_id)
        return Preset(**rec) if rec else None

    def create(self, data: PresetCreate) -> Preset:
        rec = store.insert(self.COLLECTION, data.model_dump())
        return Preset(**rec)

    def update(self, preset_id: str, data: PresetCreate) -> Preset | None:
        rec = store.update(self.COLLECTION, preset_id, data.model_dump())
        return Preset(**rec) if rec else None

    def delete(self, preset_id: str) -> bool:
        rec = store.get(self.COLLECTION, preset_id)
        if not rec:
            return False
        if rec.get("builtin"):
            return False
        return store.delete(self.COLLECTION, preset_id)


preset_service = PresetService()
