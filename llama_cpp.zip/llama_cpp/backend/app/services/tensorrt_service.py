"""TensorRT-LLM integration.

This is a thin orchestration layer around the official TensorRT-LLM toolchain
(trtllm-build, trtllm-run). The full conversion / engine-build pipeline is
heavy and environment-specific, so this service focuses on:

* detecting whether TensorRT-LLM is present;
* providing a configurable build wizard that emits the actual CLI commands;
* tracking known engines as JSON records.
"""
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path
from typing import Optional

from app.storage import store
from app.utils.logging import get_logger

log = get_logger(__name__)


class TensorRTService:
    COLLECTION = "tensorrt_engines"

    def detect(self) -> dict[str, Optional[str]]:
        info: dict[str, Optional[str]] = {
            "available": False,
            "trtllm_build": shutil.which("trtllm-build"),
            "trtllm_run": shutil.which("trtllm-run"),
            "version": None,
        }
        if info["trtllm_build"]:
            info["available"] = True
            try:
                out = subprocess.run(
                    [info["trtllm_build"], "--version"],
                    capture_output=True, text=True, timeout=10,
                )
                info["version"] = (out.stdout or out.stderr).strip().splitlines()[0] if out.stdout or out.stderr else None
            except Exception as exc:
                log.warning("trtllm-build --version failed: %s", exc)
        return info

    def plan_build(
        self,
        *,
        checkpoint_dir: str,
        output_dir: str,
        precision: str = "float16",
        max_batch_size: int = 8,
        max_input_len: int = 2048,
        max_output_len: int = 512,
        paged_kv_cache: bool = True,
        use_fused_mlp: bool = True,
    ) -> list[str]:
        cmd = [
            "trtllm-build",
            "--checkpoint_dir", checkpoint_dir,
            "--output_dir", output_dir,
            "--gemm_plugin", precision,
            "--max_batch_size", str(max_batch_size),
            "--max_input_len", str(max_input_len),
            "--max_output_len", str(max_output_len),
        ]
        if paged_kv_cache:
            cmd += ["--paged_kv_cache", "enable"]
        if use_fused_mlp:
            cmd += ["--use_fused_mlp"]
        return cmd

    def list_engines(self) -> list[dict]:
        return store.list(self.COLLECTION)

    def register_engine(self, name: str, path: str, precision: str, source_model: str) -> dict:
        return store.insert(self.COLLECTION, {
            "name": name, "path": path, "precision": precision, "source_model": source_model,
            "exists": Path(path).exists(),
        })


tensorrt_service = TensorRTService()
