"""GGUF model discovery, metadata extraction, HuggingFace download."""
from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Optional

from app.config import settings
from app.schemas import ModelDownloadRequest, ModelRecord
from app.storage import store
from app.utils.logging import get_logger

log = get_logger(__name__)

try:
    from gguf import GGUFReader  # type: ignore
    _HAS_GGUF = True
except Exception:  # pragma: no cover
    _HAS_GGUF = False

try:
    from huggingface_hub import hf_hub_download  # type: ignore
    _HAS_HF = True
except Exception:  # pragma: no cover
    _HAS_HF = False


class ModelService:
    COLLECTION = "models"

    def list(self) -> list[ModelRecord]:
        return [ModelRecord(**m) for m in store.list(self.COLLECTION)]

    def scan(self, root: Optional[Path] = None) -> list[ModelRecord]:
        root = root or settings.models_dir
        found: list[ModelRecord] = []
        for path in root.rglob("*.gguf"):
            rec = self._inspect(path)
            found.append(rec)
        # Upsert by absolute path.
        for rec in found:
            existing = next((m for m in store.list(self.COLLECTION) if m.get("path") == rec.path), None)
            if existing:
                store.update(self.COLLECTION, existing["id"], rec.model_dump(exclude={"id"}))
                rec.id = existing["id"]
            else:
                inserted = store.insert(self.COLLECTION, rec.model_dump(exclude_none=True))
                rec.id = inserted["id"]
        return found

    def _inspect(self, path: Path) -> ModelRecord:
        size = path.stat().st_size
        rec = ModelRecord(name=path.name, path=str(path), size_bytes=size)
        if _HAS_GGUF:
            try:
                reader = GGUFReader(str(path))
                fields = {f.name: f for f in reader.fields.values()}
                rec.architecture = self._field_str(fields.get("general.architecture"))
                quant_id = self._field_str(fields.get("general.file_type")) or self._field_str(fields.get("general.quantization_version"))
                rec.quantization = quant_id or self._infer_quant_from_filename(path.name)
                ctx = self._field_int(fields.get(f"{rec.architecture}.context_length")) if rec.architecture else None
                rec.context_length = ctx
                rec.parameter_count = self._field_int(fields.get("general.parameter_count"))
                rec.tokenizer = self._field_str(fields.get("tokenizer.ggml.model"))
            except Exception as exc:
                log.debug("gguf inspect failed for %s: %s", path, exc)
                rec.quantization = self._infer_quant_from_filename(path.name)
        else:
            rec.quantization = self._infer_quant_from_filename(path.name)
        # Estimate VRAM ~= file size + KV cache headroom.
        rec.estimated_vram_mb = int(size / (1024 * 1024)) + 600
        return rec

    @staticmethod
    def _field_str(field) -> Optional[str]:
        if field is None:
            return None
        try:
            data = field.parts[field.data[0]]
            if hasattr(data, "tobytes"):
                return data.tobytes().decode("utf-8", errors="replace")
            return str(data)
        except Exception:
            return None

    @staticmethod
    def _field_int(field) -> Optional[int]:
        if field is None:
            return None
        try:
            return int(field.parts[field.data[0]])
        except Exception:
            return None

    @staticmethod
    def _infer_quant_from_filename(name: str) -> Optional[str]:
        upper = name.upper()
        for q in ("Q2_K", "Q3_K_M", "Q3_K_S", "Q4_K_M", "Q4_K_S", "Q5_K_M", "Q5_K_S", "Q6_K", "Q8_0", "F16", "FP16"):
            if q in upper:
                return q
        return None

    def download(self, req: ModelDownloadRequest) -> ModelRecord:
        if not _HAS_HF:
            raise RuntimeError("huggingface_hub not installed")
        path = hf_hub_download(
            repo_id=req.repo_id,
            filename=req.filename,
            revision=req.revision or "main",
            local_dir=str(settings.models_dir),
        )
        rec = self._inspect(Path(path))
        rec.source = f"hf:{req.repo_id}/{req.filename}"
        inserted = store.insert(self.COLLECTION, rec.model_dump(exclude_none=True))
        rec.id = inserted["id"]
        return rec

    def set_favorite(self, model_id: str, favorite: bool) -> ModelRecord | None:
        rec = store.update(self.COLLECTION, model_id, {"favorite": favorite})
        return ModelRecord(**rec) if rec else None

    def hash(self, path: Path, chunk: int = 1 << 20) -> str:
        h = hashlib.sha256()
        with path.open("rb") as fh:
            while True:
                buf = fh.read(chunk)
                if not buf:
                    break
                h.update(buf)
        return h.hexdigest()


model_service = ModelService()
