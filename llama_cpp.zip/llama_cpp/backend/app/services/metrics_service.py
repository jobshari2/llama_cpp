"""Live system metrics sampler used by benchmarks and the dashboard."""
from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Optional

import psutil

from app.utils.logging import get_logger

log = get_logger(__name__)

try:
    import pynvml  # type: ignore
    _HAS_NVML = True
except Exception:
    _HAS_NVML = False


@dataclass
class MetricsAccumulator:
    samples_gpu_util: list[float] = field(default_factory=list)
    samples_vram_mb: list[float] = field(default_factory=list)
    samples_ram_mb: list[float] = field(default_factory=list)
    samples_temp_c: list[float] = field(default_factory=list)
    samples_power_w: list[float] = field(default_factory=list)
    started_at: float = field(default_factory=time.time)

    @property
    def avg_gpu_util(self) -> Optional[float]:
        return sum(self.samples_gpu_util) / len(self.samples_gpu_util) if self.samples_gpu_util else None

    @property
    def peak_vram(self) -> Optional[float]:
        return max(self.samples_vram_mb) if self.samples_vram_mb else None

    @property
    def avg_vram(self) -> Optional[float]:
        return sum(self.samples_vram_mb) / len(self.samples_vram_mb) if self.samples_vram_mb else None

    @property
    def peak_ram(self) -> Optional[float]:
        return max(self.samples_ram_mb) if self.samples_ram_mb else None

    @property
    def peak_temp(self) -> Optional[float]:
        return max(self.samples_temp_c) if self.samples_temp_c else None

    @property
    def avg_power(self) -> Optional[float]:
        return sum(self.samples_power_w) / len(self.samples_power_w) if self.samples_power_w else None


class MetricsService:
    def __init__(self) -> None:
        self._nvml_ok = False
        if _HAS_NVML:
            try:
                pynvml.nvmlInit()
                self._nvml_ok = True
            except Exception:
                self._nvml_ok = False

    def sample_once(self, acc: MetricsAccumulator) -> None:
        try:
            mem = psutil.virtual_memory()
            acc.samples_ram_mb.append(mem.used / (1024 * 1024))
        except Exception:
            pass
        if not self._nvml_ok:
            return
        try:
            n = pynvml.nvmlDeviceGetCount()
            if n == 0:
                return
            h = pynvml.nvmlDeviceGetHandleByIndex(0)
            mem = pynvml.nvmlDeviceGetMemoryInfo(h)
            util = pynvml.nvmlDeviceGetUtilizationRates(h)
            acc.samples_vram_mb.append(mem.used / (1024 * 1024))
            acc.samples_gpu_util.append(util.gpu)
            try:
                acc.samples_temp_c.append(pynvml.nvmlDeviceGetTemperature(h, pynvml.NVML_TEMPERATURE_GPU))
            except Exception:
                pass
            try:
                acc.samples_power_w.append(pynvml.nvmlDeviceGetPowerUsage(h) / 1000.0)
            except Exception:
                pass
        except Exception as exc:
            log.debug("metrics sample failed: %s", exc)

    async def sample_loop(self, acc: MetricsAccumulator, interval: float, stop_event: asyncio.Event) -> None:
        while not stop_event.is_set():
            self.sample_once(acc)
            try:
                await asyncio.wait_for(stop_event.wait(), timeout=interval)
            except asyncio.TimeoutError:
                pass


metrics_service = MetricsService()
