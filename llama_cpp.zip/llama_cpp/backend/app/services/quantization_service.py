"""Auto quantization recommendations.

Heuristic engine: given VRAM, model parameter count, target context, and a
quality preference, pick a primary quantization with rationale.
"""
from __future__ import annotations

from typing import Literal, Optional

from app.data.quantizations import QUANTIZATIONS
from app.schemas import QuantizationRecommendation, QuantInfo

QualityTarget = Literal["best", "balanced", "speed"]


class QuantizationService:
    def list(self) -> list[QuantInfo]:
        return list(QUANTIZATIONS)

    def estimate_model_vram_mb(self, params_b: float, quant: QuantInfo, ctx_size: int = 4096) -> int:
        """Rough estimate: bits-per-weight × params + KV cache + overhead."""
        weights_mb = params_b * 1_000_000_000 * (quant.bits_per_weight / 8) / (1024 * 1024)
        # KV cache approx: 2 * n_layers * hidden * ctx * 2 bytes ; use small constant for ballpark.
        kv_mb = max(64, int(ctx_size * 0.06 * params_b))
        overhead_mb = 350
        return int(weights_mb + kv_mb + overhead_mb)

    def recommend(
        self,
        *,
        available_vram_mb: int,
        params_b: float = 7.0,
        ctx_size: int = 4096,
        target: QualityTarget = "balanced",
        is_jetson: bool = False,
    ) -> QuantizationRecommendation:
        # Score quants given constraints.
        scored: list[tuple[QuantInfo, float, int]] = []
        for q in QUANTIZATIONS:
            est = self.estimate_model_vram_mb(params_b, q, ctx_size)
            fits = est <= available_vram_mb
            score = 0.0
            if fits:
                # Headroom-aware base score; prefer biggest that fits when target=best.
                headroom = available_vram_mb - est
                if target == "best":
                    score = q.quality * 10 + (headroom / 1000)
                elif target == "speed":
                    score = q.speed * 10 + (headroom / 1000)
                else:
                    score = (q.quality + q.speed) * 5 + (headroom / 1000)
            else:
                score = -1000 + (available_vram_mb - est) / 1000  # negative; prefer least over-budget
            if is_jetson:
                # Jetson Orin Nano rewards smaller, faster quants.
                score += (10 - q.bits_per_weight) * 1.5
            scored.append((q, score, est))

        scored.sort(key=lambda t: t[1], reverse=True)
        primary, _, est = scored[0]
        alternatives = [s[0].name for s in scored[1:4] if s[1] > -500]

        if est > available_vram_mb:
            reason = (
                f"No quantization fits a {params_b:.1f}B model at ctx={ctx_size} in "
                f"{available_vram_mb} MB VRAM. {primary.name} is least over-budget by ~{est - available_vram_mb} MB; "
                "consider reducing context or moving layers to CPU."
            )
        else:
            reason = (
                f"{primary.name} ({primary.bits_per_weight} bpw) fits in {available_vram_mb} MB with ~"
                f"{available_vram_mb - est} MB headroom. Quality {primary.quality}/10, speed {primary.speed}/10."
            )
            if is_jetson:
                reason += " Jetson optimization preferred a smaller quant."

        return QuantizationRecommendation(
            primary=primary.name,
            alternatives=alternatives,
            reasoning=reason,
            estimated_vram_mb=est,
            quality_score=primary.quality,
            speed_score=primary.speed,
            table=list(QUANTIZATIONS),
        )


quantization_service = QuantizationService()
