"""Cross-platform hardware detection.

Uses `psutil` for CPU/memory/storage, `pynvml` for NVIDIA GPUs (when available),
and `jtop` (jetson-stats) for Jetson devices. Each capability degrades
gracefully — the absence of a library doesn't fail the whole detection run.
"""
from __future__ import annotations

import datetime as _dt
import platform
import shutil
import socket
import subprocess
from pathlib import Path
from typing import Optional

import psutil

from app.schemas import (
    CpuInfo, GpuInfo, HardwareSnapshot, JetsonInfo,
    MemoryInfo, StorageDevice, StorageInfo,
)
from app.storage import store
from app.utils.logging import get_logger

log = get_logger(__name__)

try:  # pynvml is best-effort
    import pynvml  # type: ignore
    _HAS_NVML = True
except Exception:  # pragma: no cover
    _HAS_NVML = False


class HardwareService:
    def __init__(self) -> None:
        self._nvml_initialised = False

    # ---------- Public API ----------

    def snapshot(self, persist: bool = True) -> HardwareSnapshot:
        snap = HardwareSnapshot(
            platform=platform.platform(),
            os=platform.system(),
            hostname=socket.gethostname(),
            gpus=self._collect_gpus(),
            cpu=self._collect_cpu(),
            memory=self._collect_memory(),
            storage=self._collect_storage(),
            jetson=self._collect_jetson(),
            captured_at=_dt.datetime.now(_dt.timezone.utc).isoformat(),
        )
        if persist:
            store.set_singleton("hardware_latest", snap.model_dump())
            store.insert("hardware_history", snap.model_dump())
        return snap

    # ---------- GPU ----------

    def _ensure_nvml(self) -> bool:
        if not _HAS_NVML:
            return False
        if self._nvml_initialised:
            return True
        try:
            pynvml.nvmlInit()
            self._nvml_initialised = True
            return True
        except Exception as exc:
            log.info("NVML init failed (no NVIDIA GPU?): %s", exc)
            return False

    def _collect_gpus(self) -> list[GpuInfo]:
        if not self._ensure_nvml():
            return []
        gpus: list[GpuInfo] = []
        try:
            n = pynvml.nvmlDeviceGetCount()
            driver = pynvml.nvmlSystemGetDriverVersion()
            cuda_v: Optional[str] = None
            try:
                cuda_v = str(pynvml.nvmlSystemGetCudaDriverVersion())
                # NVML returns major*1000 + minor*10
                if cuda_v and cuda_v.isdigit():
                    n_int = int(cuda_v)
                    cuda_v = f"{n_int // 1000}.{(n_int % 1000) // 10}"
            except Exception:
                pass
            for i in range(n):
                h = pynvml.nvmlDeviceGetHandleByIndex(i)
                name = pynvml.nvmlDeviceGetName(h)
                if isinstance(name, bytes):
                    name = name.decode()
                mem = pynvml.nvmlDeviceGetMemoryInfo(h)
                util = pynvml.nvmlDeviceGetUtilizationRates(h)
                temp = power = sm_clock = mem_clock = None
                cc = None
                try:
                    temp = pynvml.nvmlDeviceGetTemperature(h, pynvml.NVML_TEMPERATURE_GPU)
                except Exception:
                    pass
                try:
                    power = pynvml.nvmlDeviceGetPowerUsage(h) / 1000.0
                except Exception:
                    pass
                try:
                    sm_clock = pynvml.nvmlDeviceGetClockInfo(h, pynvml.NVML_CLOCK_SM)
                    mem_clock = pynvml.nvmlDeviceGetClockInfo(h, pynvml.NVML_CLOCK_MEM)
                except Exception:
                    pass
                try:
                    major, minor = pynvml.nvmlDeviceGetCudaComputeCapability(h)
                    cc = f"{major}.{minor}"
                except Exception:
                    pass
                gpus.append(GpuInfo(
                    index=i,
                    name=str(name),
                    vram_total_mb=int(mem.total / (1024 * 1024)),
                    vram_free_mb=int(mem.free / (1024 * 1024)),
                    vram_used_mb=int(mem.used / (1024 * 1024)),
                    cuda_version=cuda_v,
                    driver_version=str(driver),
                    compute_capability=cc,
                    tensor_cores=cc is not None and float(cc) >= 7.0,
                    sm_clock_mhz=sm_clock,
                    mem_clock_mhz=mem_clock,
                    temperature_c=temp,
                    power_w=power,
                    utilization_percent=util.gpu,
                ))
        except Exception as exc:
            log.warning("GPU collection failed: %s", exc)
        return gpus

    # ---------- CPU ----------

    def _collect_cpu(self) -> CpuInfo:
        freq = psutil.cpu_freq()
        return CpuInfo(
            physical_cores=psutil.cpu_count(logical=False) or 1,
            logical_cores=psutil.cpu_count(logical=True) or 1,
            architecture=platform.machine(),
            model=platform.processor() or None,
            base_freq_mhz=freq.min if freq else None,
            current_freq_mhz=freq.current if freq else None,
            load_percent=psutil.cpu_percent(interval=0.05),
        )

    # ---------- Memory ----------

    def _collect_memory(self) -> MemoryInfo:
        mem = psutil.virtual_memory()
        swap = psutil.swap_memory()
        return MemoryInfo(
            total_mb=int(mem.total / (1024 * 1024)),
            free_mb=int(mem.available / (1024 * 1024)),
            used_mb=int(mem.used / (1024 * 1024)),
            swap_total_mb=int(swap.total / (1024 * 1024)),
            swap_free_mb=int(swap.free / (1024 * 1024)),
        )

    # ---------- Storage ----------

    def _collect_storage(self) -> StorageInfo:
        devices: list[StorageDevice] = []
        for part in psutil.disk_partitions(all=False):
            try:
                usage = psutil.disk_usage(part.mountpoint)
            except Exception:
                continue
            name = (part.device or "").lower()
            devices.append(StorageDevice(
                mount=part.mountpoint,
                fstype=part.fstype,
                total_gb=round(usage.total / (1024 ** 3), 2),
                free_gb=round(usage.free / (1024 ** 3), 2),
                is_nvme="nvme" in name,
                is_ssd=("ssd" in name) or ("nvme" in name) or None,
            ))
        return StorageInfo(devices=devices)

    # ---------- Jetson ----------

    def _collect_jetson(self) -> JetsonInfo:
        info = JetsonInfo()
        # Hint #1: /etc/nv_tegra_release exists only on Jetson.
        tegra = Path("/etc/nv_tegra_release")
        if tegra.exists():
            info.is_jetson = True
            try:
                content = tegra.read_text(errors="ignore").strip()
                info.jetpack_version = content.split(",")[0].strip()
            except Exception:
                pass
        # Hint #2: /proc/device-tree/model often contains "NVIDIA Jetson...".
        model = Path("/proc/device-tree/model")
        if model.exists():
            try:
                m = model.read_text(errors="ignore").strip().replace("\x00", "")
                if "jetson" in m.lower():
                    info.is_jetson = True
                    info.model = m
            except Exception:
                pass
        if not info.is_jetson:
            return info
        # Try jetson-stats jtop for richer data — best-effort.
        try:
            from jtop import jtop  # type: ignore
            with jtop() as jt:
                if jt.ok():
                    try:
                        info.nvpmodel = jt.nvpmodel.name if jt.nvpmodel else None
                    except Exception:
                        pass
                    try:
                        info.jetson_clocks_active = bool(jt.jetson_clocks)
                    except Exception:
                        pass
                    try:
                        stats = jt.stats
                        info.thermal_mode = stats.get("Temp CPU")
                    except Exception:
                        pass
        except Exception as exc:  # pragma: no cover
            log.debug("jtop unavailable: %s", exc)
        # CLI fallbacks for component versions.
        info.cuda_version = info.cuda_version or _safe_cmd(["nvcc", "--version"])
        info.tensorrt_version = info.tensorrt_version or _read_first_line("/usr/include/NvInferVersion.h")
        return info


def _safe_cmd(argv: list[str]) -> Optional[str]:
    try:
        if not shutil.which(argv[0]):
            return None
        out = subprocess.run(argv, capture_output=True, text=True, timeout=5)
        return out.stdout.strip() or None
    except Exception:
        return None


def _read_first_line(path: str) -> Optional[str]:
    p = Path(path)
    if not p.exists():
        return None
    try:
        return p.read_text(errors="ignore").splitlines()[0]
    except Exception:
        return None


hardware_service = HardwareService()
