"""Search the configuration space for fastest / balanced / lowest-memory configs.

Strategy: generate a small set of candidate configs varying gpu_layers,
batch_size, flash_attn, and KV cache type, then run real benchmarks (within
the requested budget) and score each by goal-specific weights.
"""
from __future__ import annotations

import asyncio
from typing import Any

from app.schemas import (
    BenchmarkRequest, LlamaConfig, OptimizationCandidate, OptimizationGoal,
    OptimizeRequest, OptimizeResponse,
)
from app.services.benchmark_service import benchmark_service
from app.services.hardware_service import hardware_service
from app.utils.logging import get_logger

log = get_logger(__name__)


class OptimizationService:
    async def optimize(self, req: OptimizeRequest) -> OptimizeResponse:
        hw = hardware_service.snapshot(persist=False)
        gpu_vram = hw.gpus[0].vram_total_mb if hw.gpus else 0
        is_jetson = hw.jetson.is_jetson

        base = req.starting_config or LlamaConfig(model_path=req.model_path)
        # Force model_path to the requested one even if starting_config differs.
        base = base.model_copy(update={"model_path": req.model_path})
        candidates = self._generate_candidates(base, gpu_vram, is_jetson)[: req.max_runs]

        results: list[OptimizationCandidate] = []
        for cfg, rationale in candidates:
            bench = await benchmark_service.run(BenchmarkRequest(
                config=cfg, prompt="The quick brown fox jumps over the lazy dog. " * 8,
                n_predict=64, label="optimization-search",
            ))
            score = self._score(bench.model_dump(), req.goal)
            results.append(OptimizationCandidate(
                config=cfg, score=score, rationale=rationale, benchmark=bench,
            ))

        if not results:
            return OptimizeResponse(goal=req.goal)

        fastest = max(results, key=lambda c: (c.benchmark.token_gen_tps if c.benchmark else 0))
        lowest_mem = min(results, key=lambda c: (c.benchmark.peak_vram_mb if c.benchmark and c.benchmark.peak_vram_mb else 1e9))
        most_stable = min(results, key=lambda c: (c.benchmark.peak_temperature_c if c.benchmark and c.benchmark.peak_temperature_c else 1e9))
        balanced = max(results, key=lambda c: c.score)

        return OptimizeResponse(
            goal=req.goal,
            fastest=fastest, balanced=balanced,
            lowest_memory=lowest_mem, most_stable=most_stable,
            candidates=results,
        )

    def _generate_candidates(self, base: LlamaConfig, vram_mb: int, is_jetson: bool) -> list[tuple[LlamaConfig, str]]:
        candidates: list[tuple[LlamaConfig, str]] = []

        # 1. Aggressive GPU offload.
        candidates.append((
            base.model_copy(update={"gpu_layers": 999, "flash_attn": True, "batch_size": 1024, "ubatch_size": 1024}),
            "Full GPU offload + Flash Attention + large batch",
        ))
        # 2. Balanced.
        candidates.append((
            base.model_copy(update={"gpu_layers": 999, "flash_attn": True, "batch_size": 512, "ubatch_size": 512}),
            "Full GPU offload, balanced batch",
        ))
        # 3. Quantized KV cache (memory saver).
        candidates.append((
            base.model_copy(update={"gpu_layers": 999, "flash_attn": True, "cache_type_k": "q8_0",
                                    "cache_type_v": "q8_0", "batch_size": 256, "ubatch_size": 256}),
            "Q8_0 KV cache for lower VRAM",
        ))
        # 4. Conservative (CPU/GPU split).
        partial = max(0, min(40, int(vram_mb / 350))) if vram_mb else 0
        candidates.append((
            base.model_copy(update={"gpu_layers": partial, "flash_attn": False, "batch_size": 256, "ubatch_size": 256}),
            f"Partial offload ({partial} layers) — safest fallback",
        ))
        # 5. Jetson tuned.
        if is_jetson:
            candidates.insert(0, (
                base.model_copy(update={"gpu_layers": 99, "flash_attn": True, "batch_size": 128,
                                        "ubatch_size": 128, "ctx_size": 2048, "cache_type_k": "q8_0",
                                        "cache_type_v": "q8_0", "threads": 6}),
                "Jetson-tuned: small batch, q8 KV, ctx 2048",
            ))
        return candidates

    def _score(self, b: dict[str, Any], goal: OptimizationGoal) -> float:
        tps = b.get("token_gen_tps") or 0
        vram = b.get("peak_vram_mb") or 0
        latency = b.get("latency_first_token_ms") or 1000
        temp = b.get("peak_temperature_c") or 0
        if not b.get("success", True):
            return -1000
        if goal == "fastest":
            return tps - latency * 0.01
        if goal == "lowest_memory":
            return -vram + tps * 0.1
        if goal == "most_stable":
            return -temp + tps * 0.05 - vram * 0.001
        if goal == "best_quality":
            return tps * 0.3 - latency * 0.005
        # balanced
        return tps - vram * 0.001 - latency * 0.005


optimization_service = OptimizationService()
