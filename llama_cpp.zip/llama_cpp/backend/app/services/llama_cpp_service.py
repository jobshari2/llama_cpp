"""Locate and run llama.cpp binaries."""
from __future__ import annotations

import asyncio
import os
import shutil
import subprocess
from pathlib import Path
from typing import AsyncIterator, Optional

from app.config import settings
from app.schemas import AppSettings, LlamaConfig
from app.storage import store
from app.utils.command_builder import build_llama_cli_command, quote_for_display
from app.utils.logging import get_logger

log = get_logger(__name__)


class LlamaCppNotFound(RuntimeError):
    pass


class LlamaCppService:
    """Owns binary discovery and process launching for llama.cpp."""

    BINARY_CANDIDATES = ("llama-cli", "llama-cli.exe", "main", "main.exe")

    def get_settings(self) -> AppSettings:
        raw = store.get_singleton("settings", default={})
        return AppSettings(**raw) if raw else AppSettings()

    def save_settings(self, payload: AppSettings) -> AppSettings:
        store.set_singleton("settings", payload.model_dump())
        return payload

    def discover_binary(self) -> Optional[str]:
        cfg = self.get_settings()
        if cfg.llama_cli_path and Path(cfg.llama_cli_path).exists():
            return cfg.llama_cli_path
        # Built into vendor/llama.cpp by our install script.
        for sub in ("build/bin", "build/bin/Release", "build/Release", "bin"):
            for cand in self.BINARY_CANDIDATES:
                p = settings.llama_cpp_root / sub / cand
                if p.exists():
                    return str(p)
        for cand in self.BINARY_CANDIDATES:
            on_path = shutil.which(cand)
            if on_path:
                return on_path
        return None

    def require_binary(self) -> str:
        b = self.discover_binary()
        if not b:
            raise LlamaCppNotFound(
                "llama.cpp binary not found. Run scripts/install_llama_cpp.{sh,ps1} "
                "or set llama_cli_path in app settings."
            )
        return b

    def version(self) -> Optional[str]:
        try:
            b = self.require_binary()
        except LlamaCppNotFound:
            return None
        try:
            out = subprocess.run([b, "--version"], capture_output=True, text=True, timeout=10)
            return (out.stdout + out.stderr).strip().splitlines()[0] if (out.stdout or out.stderr) else None
        except Exception as exc:
            log.warning("llama.cpp --version failed: %s", exc)
            return None

    def build_command(self, cfg: LlamaConfig, *, prompt: str | None = None) -> list[str]:
        b = self.require_binary()
        return build_llama_cli_command(b, cfg, prompt=prompt)

    def preview_command(self, cfg: LlamaConfig, *, prompt: str | None = None) -> str:
        return quote_for_display(self.build_command(cfg, prompt=prompt))

    async def stream_inference(self, cfg: LlamaConfig, prompt: str) -> AsyncIterator[str]:
        """Async-iterate stdout lines as llama.cpp generates output."""
        cmd = self.build_command(cfg, prompt=prompt)
        log.info("running: %s", quote_for_display(cmd))
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env={**os.environ},
        )
        assert proc.stdout is not None
        try:
            while True:
                chunk = await proc.stdout.read(64)
                if not chunk:
                    break
                yield chunk.decode("utf-8", errors="replace")
        finally:
            await proc.wait()


llama_cpp_service = LlamaCppService()
