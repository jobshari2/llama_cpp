"""Run a llama.cpp benchmark and parse results.

llama.cpp emits structured eval/timing lines on stderr we can scrape:
    `prompt eval time =  ...  / ... runs ( ... ms per token, ... tokens per second)`
    `eval time       =  ...  / ... runs ( ... ms per token, ... tokens per second)`
"""
from __future__ import annotations

import asyncio
import re
import time
from typing import Optional

from app.schemas import BenchmarkRequest, BenchmarkResult
from app.services.llama_cpp_service import LlamaCppNotFound, llama_cpp_service
from app.services.metrics_service import MetricsAccumulator, metrics_service
from app.storage import store
from app.utils.command_builder import quote_for_display
from app.utils.logging import get_logger

log = get_logger(__name__)


_TIMING_RE = re.compile(
    r"(prompt eval time|eval time|total time)\s*=\s*([\d.]+)\s*ms\s*/\s*(\d+)\s*(?:tokens|runs)?"
)
_TPS_RE = re.compile(r"\(([^)]*?)([\d.]+)\s*tokens per second\)")


class BenchmarkService:
    async def run(self, req: BenchmarkRequest) -> BenchmarkResult:
        try:
            cmd = llama_cpp_service.build_command(req.config, prompt=req.prompt)
        except LlamaCppNotFound as exc:
            return BenchmarkResult(
                config=req.config, label=req.label, success=False, error=str(exc),
            )
        log.info("benchmark command: %s", quote_for_display(cmd))

        acc = MetricsAccumulator()
        stop = asyncio.Event()
        sampler = asyncio.create_task(metrics_service.sample_loop(acc, 0.5, stop))

        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        assert proc.stdout is not None and proc.stderr is not None
        start = time.time()
        first_token_at: Optional[float] = None
        stdout_acc: list[str] = []
        stderr_acc: list[str] = []

        async def read_stdout() -> None:
            nonlocal first_token_at
            assert proc.stdout is not None
            while True:
                chunk = await proc.stdout.read(64)
                if not chunk:
                    break
                if first_token_at is None and chunk.strip():
                    first_token_at = time.time()
                stdout_acc.append(chunk.decode("utf-8", errors="replace"))

        async def read_stderr() -> None:
            assert proc.stderr is not None
            while True:
                line = await proc.stderr.readline()
                if not line:
                    break
                stderr_acc.append(line.decode("utf-8", errors="replace"))

        try:
            await asyncio.wait_for(
                asyncio.gather(read_stdout(), read_stderr(), proc.wait()),
                timeout=600,
            )
        except asyncio.TimeoutError:
            proc.kill()
            stop.set()
            await sampler
            return BenchmarkResult(
                config=req.config, label=req.label, success=False,
                error="benchmark exceeded 600s timeout",
            )

        stop.set()
        await sampler
        wall = time.time() - start

        result = self._parse_output("".join(stderr_acc) + "".join(stdout_acc))
        peak_vram = acc.peak_vram
        result_obj = BenchmarkResult(
            label=req.label,
            config=req.config,
            prompt_tokens=result.get("prompt_tokens", 0),
            generated_tokens=result.get("eval_tokens", 0),
            prompt_eval_tps=result.get("prompt_tps", 0.0),
            token_gen_tps=result.get("eval_tps", 0.0),
            total_seconds=wall,
            latency_first_token_ms=(first_token_at - start) * 1000.0 if first_token_at else None,
            peak_vram_mb=peak_vram,
            avg_vram_mb=acc.avg_vram,
            peak_ram_mb=acc.peak_ram,
            avg_gpu_utilization=acc.avg_gpu_util,
            peak_temperature_c=acc.peak_temp,
            avg_power_w=acc.avg_power,
            throttled=(acc.peak_temp or 0) >= 85.0,
            success=proc.returncode == 0,
            error=None if proc.returncode == 0 else f"exit {proc.returncode}",
            log_excerpt="".join(stderr_acc[-40:]),
        )
        stored = store.insert("benchmarks", result_obj.model_dump())
        result_obj.id = stored["id"]
        result_obj.created_at = stored["created_at"]
        return result_obj

    def _parse_output(self, text: str) -> dict[str, float | int]:
        out: dict[str, float | int] = {}
        for line in text.splitlines():
            m = _TIMING_RE.search(line)
            if not m:
                continue
            kind = m.group(1)
            count = int(m.group(3))
            tps_match = _TPS_RE.search(line)
            tps = float(tps_match.group(2)) if tps_match else 0.0
            if kind == "prompt eval time":
                out["prompt_tokens"] = count
                out["prompt_tps"] = tps
            elif kind == "eval time":
                out["eval_tokens"] = count
                out["eval_tps"] = tps
        return out

    def history(self, limit: int = 100) -> list[BenchmarkResult]:
        items = store.list("benchmarks")[-limit:]
        return [BenchmarkResult(**it) for it in items]

    def compare(self, ids: list[str]) -> list[BenchmarkResult]:
        out: list[BenchmarkResult] = []
        for i in ids:
            rec = store.get("benchmarks", i)
            if rec:
                out.append(BenchmarkResult(**rec))
        return out


benchmark_service = BenchmarkService()
