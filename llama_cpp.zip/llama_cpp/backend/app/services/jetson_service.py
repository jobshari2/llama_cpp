"""Jetson-specific runtime tuning helpers.

These helpers run privileged commands (`nvpmodel`, `jetson_clocks`, swap
adjustments). They are gated by an explicit `apply` boolean — `dry_run`
mode just returns the commands that would be executed.
"""
from __future__ import annotations

import shutil
import subprocess
from typing import Optional

from app.utils.logging import get_logger

log = get_logger(__name__)


class JetsonService:
    def is_jetson(self) -> bool:
        from pathlib import Path
        return Path("/etc/nv_tegra_release").exists()

    def list_power_modes(self) -> list[str]:
        if not shutil.which("nvpmodel"):
            return []
        try:
            out = subprocess.run(["nvpmodel", "-p", "--verbose"], capture_output=True, text=True, timeout=5)
            return [l.strip() for l in out.stdout.splitlines() if l.strip()]
        except Exception:
            return []

    def set_power_mode(self, mode_id: int, *, apply: bool) -> dict:
        cmd = ["sudo", "nvpmodel", "-m", str(mode_id)]
        if not apply:
            return {"command": cmd, "applied": False}
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        return {"command": cmd, "applied": True, "stdout": result.stdout, "returncode": result.returncode}

    def jetson_clocks(self, *, apply: bool, show: bool = False) -> dict:
        cmd = ["sudo", "jetson_clocks"]
        if show:
            cmd.append("--show")
        if not apply:
            return {"command": cmd, "applied": False}
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        return {"command": cmd, "applied": True, "stdout": result.stdout, "returncode": result.returncode}

    def swap_adjust(self, size_gb: int, *, apply: bool, swap_path: str = "/var/swapfile") -> dict:
        commands = [
            ["sudo", "fallocate", "-l", f"{size_gb}G", swap_path],
            ["sudo", "chmod", "600", swap_path],
            ["sudo", "mkswap", swap_path],
            ["sudo", "swapon", swap_path],
        ]
        if not apply:
            return {"commands": commands, "applied": False}
        outputs = []
        for c in commands:
            outputs.append(subprocess.run(c, capture_output=True, text=True, timeout=60).returncode)
        return {"commands": commands, "applied": True, "returncodes": outputs}


jetson_service = JetsonService()
