"""Atomic JSON file store. Each collection lives in its own file under data/."""
from __future__ import annotations

import json
import os
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from app.config import settings


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def _atomic_write(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2, default=str)
    os.replace(tmp, path)


class JsonStore:
    """Thread-safe JSON-file collections.

    Each `collection` is a JSON file containing a list of records keyed by `id`.
    Singletons (settings, latest hardware) are stored as `{<key>: ...}` dicts.
    """

    def __init__(self, root: Path | None = None) -> None:
        self.root = Path(root) if root else settings.data_dir
        self.root.mkdir(parents=True, exist_ok=True)
        self._locks: dict[str, threading.Lock] = {}
        self._global = threading.Lock()

    def _lock(self, name: str) -> threading.Lock:
        with self._global:
            if name not in self._locks:
                self._locks[name] = threading.Lock()
            return self._locks[name]

    def _path(self, name: str) -> Path:
        return self.root / f"{name}.json"

    # -------- Collections (list of dicts) --------

    def list(self, collection: str) -> list[dict[str, Any]]:
        p = self._path(collection)
        if not p.exists():
            return []
        with p.open("r", encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, list) else []

    def get(self, collection: str, item_id: str) -> dict[str, Any] | None:
        for item in self.list(collection):
            if item.get("id") == item_id:
                return item
        return None

    def insert(self, collection: str, record: dict[str, Any]) -> dict[str, Any]:
        with self._lock(collection):
            items = self.list(collection)
            record = {**record}
            record.setdefault("id", str(uuid.uuid4()))
            record.setdefault("created_at", _utcnow())
            items.append(record)
            _atomic_write(self._path(collection), items)
        return record

    def update(self, collection: str, item_id: str, patch: dict[str, Any]) -> dict[str, Any] | None:
        with self._lock(collection):
            items = self.list(collection)
            for i, item in enumerate(items):
                if item.get("id") == item_id:
                    items[i] = {**item, **patch, "updated_at": _utcnow()}
                    _atomic_write(self._path(collection), items)
                    return items[i]
        return None

    def delete(self, collection: str, item_id: str) -> bool:
        with self._lock(collection):
            items = self.list(collection)
            new = [it for it in items if it.get("id") != item_id]
            if len(new) == len(items):
                return False
            _atomic_write(self._path(collection), new)
        return True

    def upsert_many(self, collection: str, records: Iterable[dict[str, Any]], key: str = "id") -> None:
        with self._lock(collection):
            items = self.list(collection)
            index = {it.get(key): i for i, it in enumerate(items)}
            for rec in records:
                k = rec.get(key)
                if k is not None and k in index:
                    items[index[k]] = {**items[index[k]], **rec, "updated_at": _utcnow()}
                else:
                    rec.setdefault("id", str(uuid.uuid4()))
                    rec.setdefault("created_at", _utcnow())
                    items.append(rec)
            _atomic_write(self._path(collection), items)

    # -------- Singletons (single dict per file) --------

    def get_singleton(self, name: str, default: dict[str, Any] | None = None) -> dict[str, Any]:
        p = self._path(name)
        if not p.exists():
            return dict(default or {})
        with p.open("r", encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else dict(default or {})

    def set_singleton(self, name: str, payload: dict[str, Any]) -> dict[str, Any]:
        with self._lock(name):
            payload = {**payload, "updated_at": _utcnow()}
            _atomic_write(self._path(name), payload)
        return payload


store = JsonStore()
