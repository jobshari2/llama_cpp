"""FastAPI application entry point."""
from __future__ import annotations

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app import __version__
from app.api import (
    benchmarks, config as config_api, dashboard, hardware, inference,
    jetson, models, optimization, presets, quantization, tensorrt,
)
from app.config import settings
from app.utils.logging import setup_logging

setup_logging()

app = FastAPI(
    title="LlamaForge",
    version=__version__,
    description="Cross-platform configuration & optimization for llama.cpp.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(hardware.router)
app.include_router(config_api.router)
app.include_router(models.router)
app.include_router(benchmarks.router)
app.include_router(optimization.router)
app.include_router(quantization.router)
app.include_router(presets.router)
app.include_router(inference.router)
app.include_router(tensorrt.router)
app.include_router(jetson.router)
app.include_router(dashboard.router)


@app.get("/api/health")
def health() -> dict:
    return {"status": "ok", "version": __version__}


@app.get("/")
def root() -> dict:
    return {
        "name": "LlamaForge",
        "version": __version__,
        "docs": "/docs",
        "health": "/api/health",
    }
