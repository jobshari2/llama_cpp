from fastapi import APIRouter

from app.schemas import HardwareSnapshot
from app.services.hardware_service import hardware_service
from app.storage import store

router = APIRouter(prefix="/api/hardware", tags=["hardware"])


@router.get("", response_model=HardwareSnapshot)
def get_hardware() -> HardwareSnapshot:
    return hardware_service.snapshot()


@router.get("/latest", response_model=HardwareSnapshot)
def get_latest() -> HardwareSnapshot:
    cached = store.get_singleton("hardware_latest")
    if cached:
        return HardwareSnapshot(**cached)
    return hardware_service.snapshot()


@router.get("/history")
def history(limit: int = 50) -> list[dict]:
    return store.list("hardware_history")[-limit:]
