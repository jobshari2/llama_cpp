from fastapi import APIRouter

from app.schemas import OptimizeRequest, OptimizeResponse
from app.services.optimization_service import optimization_service

router = APIRouter(prefix="/api/optimize", tags=["optimize"])


@router.post("/recommend", response_model=OptimizeResponse)
async def recommend(req: OptimizeRequest) -> OptimizeResponse:
    return await optimization_service.optimize(req)
