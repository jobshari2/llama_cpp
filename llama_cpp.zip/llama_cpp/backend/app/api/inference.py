"""Inference WebSocket: stream tokens + live metrics to the playground UI."""
from __future__ import annotations

import asyncio
import json
import time
from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from app.schemas import LlamaConfig
from app.services.llama_cpp_service import LlamaCppNotFound, llama_cpp_service
from app.services.metrics_service import MetricsAccumulator, metrics_service
from app.utils.logging import get_logger

router = APIRouter(prefix="/api/inference", tags=["inference"])
log = get_logger(__name__)


@router.websocket("/stream")
async def stream(ws: WebSocket) -> None:
    await ws.accept()
    try:
        msg = await ws.receive_json()
    except Exception:
        await ws.close()
        return

    try:
        cfg = LlamaConfig(**msg["config"])
        prompt = msg.get("prompt", "")
    except Exception as exc:
        await ws.send_json({"event": "error", "error": f"bad config: {exc}"})
        await ws.close()
        return

    try:
        await ws.send_json({"event": "start", "command": llama_cpp_service.preview_command(cfg, prompt=prompt)})
    except LlamaCppNotFound as exc:
        await ws.send_json({"event": "error", "error": str(exc)})
        await ws.close()
        return

    acc = MetricsAccumulator()
    stop_metrics = asyncio.Event()
    metrics_task = asyncio.create_task(metrics_service.sample_loop(acc, 0.5, stop_metrics))

    started = time.time()
    token_count = 0
    last_emit = started

    try:
        async for chunk in llama_cpp_service.stream_inference(cfg, prompt):
            token_count += chunk.count(" ")  # approximate; llama-cli prints tokenwise
            now = time.time()
            await ws.send_json({"event": "token", "chunk": chunk})
            if now - last_emit > 0.5:
                last_emit = now
                tps = token_count / max(now - started, 0.0001)
                await ws.send_json({
                    "event": "metrics",
                    "approx_tokens": token_count,
                    "tps_estimate": tps,
                    "elapsed": now - started,
                    "vram_mb": acc.peak_vram,
                    "gpu_util": acc.avg_gpu_util,
                    "temp_c": acc.peak_temp,
                })
        await ws.send_json({
            "event": "done",
            "approx_tokens": token_count,
            "elapsed": time.time() - started,
            "peak_vram_mb": acc.peak_vram,
            "avg_gpu_util": acc.avg_gpu_util,
        })
    except WebSocketDisconnect:
        pass
    except Exception as exc:
        log.exception("inference stream failed")
        try:
            await ws.send_json({"event": "error", "error": str(exc)})
        except Exception:
            pass
    finally:
        stop_metrics.set()
        await metrics_task
        try:
            await ws.close()
        except Exception:
            pass
