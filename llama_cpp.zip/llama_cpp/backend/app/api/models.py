from fastapi import APIRouter, HTTPException

from app.schemas import ModelDownloadRequest, ModelRecord
from app.services.model_service import model_service

router = APIRouter(prefix="/api/models", tags=["models"])


@router.get("", response_model=list[ModelRecord])
def list_models() -> list[ModelRecord]:
    return model_service.list()


@router.post("/scan", response_model=list[ModelRecord])
def scan() -> list[ModelRecord]:
    return model_service.scan()


@router.post("/download", response_model=ModelRecord)
def download(req: ModelDownloadRequest) -> ModelRecord:
    try:
        return model_service.download(req)
    except Exception as exc:
        raise HTTPException(500, str(exc))


@router.post("/{model_id}/favorite", response_model=ModelRecord)
def favorite(model_id: str, value: bool = True) -> ModelRecord:
    rec = model_service.set_favorite(model_id, value)
    if not rec:
        raise HTTPException(404, "model not found")
    return rec
