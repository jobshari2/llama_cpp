from fastapi import APIRouter
from pydantic import BaseModel

from app.services.tensorrt_service import tensorrt_service

router = APIRouter(prefix="/api/tensorrt", tags=["tensorrt"])


class BuildPlan(BaseModel):
    checkpoint_dir: str
    output_dir: str
    precision: str = "float16"
    max_batch_size: int = 8
    max_input_len: int = 2048
    max_output_len: int = 512
    paged_kv_cache: bool = True
    use_fused_mlp: bool = True


class RegisterEngine(BaseModel):
    name: str
    path: str
    precision: str
    source_model: str


@router.get("/detect")
def detect() -> dict:
    return tensorrt_service.detect()


@router.post("/plan-build")
def plan_build(plan: BuildPlan) -> dict:
    cmd = tensorrt_service.plan_build(**plan.model_dump())
    return {"command": cmd}


@router.get("/engines")
def engines() -> list[dict]:
    return tensorrt_service.list_engines()


@router.post("/engines")
def register(engine: RegisterEngine) -> dict:
    return tensorrt_service.register_engine(**engine.model_dump())
