from fastapi import APIRouter, HTTPException

from app.schemas import BenchmarkComparison, BenchmarkRequest, BenchmarkResult
from app.services.benchmark_service import benchmark_service

router = APIRouter(prefix="/api/benchmark", tags=["benchmark"])


@router.post("/start", response_model=BenchmarkResult)
async def start(req: BenchmarkRequest) -> BenchmarkResult:
    return await benchmark_service.run(req)


@router.get("/history", response_model=list[BenchmarkResult])
def history(limit: int = 100) -> list[BenchmarkResult]:
    return benchmark_service.history(limit=limit)


@router.post("/compare", response_model=BenchmarkComparison)
def compare(payload: BenchmarkComparison) -> BenchmarkComparison:
    results = benchmark_service.compare(payload.ids)
    if not results:
        raise HTTPException(404, "no benchmarks found for given ids")
    return BenchmarkComparison(ids=payload.ids, results=results)
