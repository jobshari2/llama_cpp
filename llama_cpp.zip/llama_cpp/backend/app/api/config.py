from fastapi import APIRouter

from app.data.llama_params import PARAMETERS, by_category
from app.schemas import AppSettings, LlamaConfig, ParamMeta
from app.services.llama_cpp_service import llama_cpp_service

router = APIRouter(prefix="/api/config", tags=["config"])


@router.get("/parameters", response_model=list[ParamMeta])
def get_parameters() -> list[ParamMeta]:
    return PARAMETERS


@router.get("/parameters/grouped")
def get_parameters_grouped() -> dict[str, list[ParamMeta]]:
    return by_category()


@router.post("/preview")
def preview_command(cfg: LlamaConfig) -> dict:
    try:
        return {"command": llama_cpp_service.preview_command(cfg)}
    except Exception as exc:
        return {"command": None, "error": str(exc)}


@router.get("/settings", response_model=AppSettings)
def get_settings() -> AppSettings:
    return llama_cpp_service.get_settings()


@router.put("/settings", response_model=AppSettings)
def update_settings(payload: AppSettings) -> AppSettings:
    return llama_cpp_service.save_settings(payload)


@router.get("/llama-version")
def llama_version() -> dict:
    return {
        "binary": llama_cpp_service.discover_binary(),
        "version": llama_cpp_service.version(),
    }
