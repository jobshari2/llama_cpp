from typing import Literal
from fastapi import APIRouter
from pydantic import BaseModel

from app.schemas import QuantInfo, QuantizationRecommendation
from app.services.quantization_service import quantization_service

router = APIRouter(prefix="/api/quantization", tags=["quantization"])


class RecommendRequest(BaseModel):
    available_vram_mb: int
    params_b: float = 7.0
    ctx_size: int = 4096
    target: Literal["best", "balanced", "speed"] = "balanced"
    is_jetson: bool = False


@router.get("", response_model=list[QuantInfo])
def list_quants() -> list[QuantInfo]:
    return quantization_service.list()


@router.post("/recommend", response_model=QuantizationRecommendation)
def recommend(req: RecommendRequest) -> QuantizationRecommendation:
    return quantization_service.recommend(
        available_vram_mb=req.available_vram_mb,
        params_b=req.params_b,
        ctx_size=req.ctx_size,
        target=req.target,
        is_jetson=req.is_jetson,
    )
