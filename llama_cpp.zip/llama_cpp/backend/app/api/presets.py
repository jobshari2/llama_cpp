from fastapi import APIRouter, HTTPException

from app.schemas import Preset, PresetCreate
from app.services.preset_service import preset_service

router = APIRouter(prefix="/api/presets", tags=["presets"])


@router.get("", response_model=list[Preset])
def list_presets() -> list[Preset]:
    return preset_service.list()


@router.post("", response_model=Preset)
def create_preset(payload: PresetCreate) -> Preset:
    return preset_service.create(payload)


@router.put("/{preset_id}", response_model=Preset)
def update_preset(preset_id: str, payload: PresetCreate) -> Preset:
    rec = preset_service.update(preset_id, payload)
    if not rec:
        raise HTTPException(404, "preset not found")
    return rec


@router.delete("/{preset_id}")
def delete_preset(preset_id: str) -> dict:
    ok = preset_service.delete(preset_id)
    if not ok:
        raise HTTPException(400, "cannot delete (not found or builtin)")
    return {"deleted": True}
