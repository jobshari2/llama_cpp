"""WebSocket that pushes a periodic system snapshot for the live dashboard."""
from __future__ import annotations

import asyncio
from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from app.services.hardware_service import hardware_service

router = APIRouter(prefix="/api/dashboard", tags=["dashboard"])


@router.websocket("/live")
async def live(ws: WebSocket) -> None:
    await ws.accept()
    try:
        while True:
            snap = hardware_service.snapshot(persist=False)
            await ws.send_json(snap.model_dump())
            await asyncio.sleep(1.0)
    except WebSocketDisconnect:
        return
