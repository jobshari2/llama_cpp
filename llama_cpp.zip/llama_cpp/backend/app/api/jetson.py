from fastapi import APIRouter
from pydantic import BaseModel

from app.services.jetson_service import jetson_service

router = APIRouter(prefix="/api/jetson", tags=["jetson"])


class PowerModeBody(BaseModel):
    mode_id: int
    apply: bool = False


class JetsonClocksBody(BaseModel):
    apply: bool = False
    show: bool = True


class SwapBody(BaseModel):
    size_gb: int
    apply: bool = False
    swap_path: str = "/var/swapfile"


@router.get("/status")
def status() -> dict:
    return {
        "is_jetson": jetson_service.is_jetson(),
        "power_modes": jetson_service.list_power_modes(),
    }


@router.post("/power-mode")
def power_mode(body: PowerModeBody) -> dict:
    return jetson_service.set_power_mode(body.mode_id, apply=body.apply)


@router.post("/jetson-clocks")
def jetson_clocks(body: JetsonClocksBody) -> dict:
    return jetson_service.jetson_clocks(apply=body.apply, show=body.show)


@router.post("/swap")
def swap(body: SwapBody) -> dict:
    return jetson_service.swap_adjust(body.size_gb, apply=body.apply, swap_path=body.swap_path)
