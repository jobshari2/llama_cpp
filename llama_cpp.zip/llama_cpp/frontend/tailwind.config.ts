import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        nv: {
          50: "#e8fbe9",
          100: "#c1f4c5",
          200: "#8be795",
          300: "#5cd773",
          400: "#34c759",
          500: "#76b900", // NVIDIA green
          600: "#5fa000",
          700: "#3f7300",
        },
        bg: {
          DEFAULT: "#0a0d10",
          surface: "#11161b",
          elevated: "#171d23",
          border: "#222a31",
        },
        text: {
          DEFAULT: "#e6edf3",
          muted: "#94a3b8",
          subtle: "#64748b",
        },
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
        mono: ["JetBrains Mono", "Menlo", "monospace"],
      },
      borderRadius: {
        xl: "0.75rem",
        "2xl": "1rem",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
};

export default config;
