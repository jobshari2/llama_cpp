import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Sparkles, Zap, MemoryStick, Shield, Sliders } from "lucide-react";
import { api, type HardwareSnapshot, type QuantizationRecommendation } from "@/lib/api";
import { useConfigStore } from "@/store/config";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Select } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Stat } from "@/components/Stat";
import { fmtMb, fmtNumber } from "@/lib/utils";

type Goal = "fastest" | "balanced" | "lowest_memory" | "most_stable" | "best_quality";

export function Optimization() {
  const config = useConfigStore((s) => s.config);
  const setConfig = useConfigStore((s) => s.setConfig);
  const [goal, setGoal] = useState<Goal>("balanced");
  const [paramsB, setParamsB] = useState(7);
  const [qTarget, setQTarget] = useState<"best" | "balanced" | "speed">("balanced");

  const { data: hw } = useQuery<HardwareSnapshot>({
    queryKey: ["hardware"],
    queryFn: () => api.get<HardwareSnapshot>("/api/hardware/latest"),
  });
  const vram = hw?.gpus?.[0]?.vram_total_mb ?? 0;
  const isJetson = hw?.jetson?.is_jetson ?? false;

  const quant = useMutation({
    mutationFn: () =>
      api.post<QuantizationRecommendation>("/api/quantization/recommend", {
        available_vram_mb: vram,
        params_b: paramsB,
        ctx_size: config.ctx_size,
        target: qTarget,
        is_jetson: isJetson,
      }),
  });

  const optimize = useMutation({
    mutationFn: () =>
      api.post("/api/optimize/recommend", {
        model_path: config.model_path,
        goal,
        max_runs: 4,
        starting_config: config,
      }),
  });

  const result = optimize.data as any;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Optimization"
        subtitle="Auto quantization recommendation and config search across goals."
      />

      <div className="card p-5 space-y-4">
        <h3 className="font-semibold flex items-center gap-2"><Sparkles className="w-4 h-4" /> Auto quantization</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <div>
            <div className="stat-label">Model size (B params)</div>
            <Input type="number" step={0.1} value={paramsB} onChange={(e) => setParamsB(Number(e.target.value))} />
          </div>
          <div>
            <div className="stat-label">VRAM</div>
            <div className="text-sm font-mono mt-2">{fmtMb(vram)}</div>
          </div>
          <div>
            <div className="stat-label">Target</div>
            <Select value={qTarget} onChange={(e) => setQTarget(e.target.value as never)}>
              <option value="balanced">balanced</option>
              <option value="best">best quality</option>
              <option value="speed">speed</option>
            </Select>
          </div>
          <div className="flex items-end">
            <Button onClick={() => quant.mutate()}>Recommend</Button>
          </div>
        </div>

        {quant.data && (
          <div className="rounded-lg bg-bg-elevated border border-bg-border p-4 space-y-2">
            <div className="text-2xl font-semibold">
              {quant.data.primary} <Badge variant="success" className="align-middle ml-2">recommended</Badge>
            </div>
            <p className="text-sm text-text-muted">{quant.data.reasoning}</p>
            <div className="flex gap-4 text-xs">
              <span>est VRAM: <strong>{fmtMb(quant.data.estimated_vram_mb)}</strong></span>
              <span>quality: <strong>{quant.data.quality_score}/10</strong></span>
              <span>speed: <strong>{quant.data.speed_score}/10</strong></span>
            </div>
            {quant.data.alternatives.length > 0 && (
              <div className="text-xs text-text-muted">Alternatives: {quant.data.alternatives.join(", ")}</div>
            )}
          </div>
        )}

        {quant.data && (
          <div className="overflow-hidden rounded-lg border border-bg-border">
            <table className="w-full text-xs">
              <thead className="bg-bg-elevated text-text-muted uppercase tracking-wider">
                <tr>
                  <th className="text-left p-2">Quant</th>
                  <th className="text-right p-2">bpw</th>
                  <th className="text-right p-2">Quality</th>
                  <th className="text-right p-2">Speed</th>
                  <th className="text-right p-2">VRAM (7B est)</th>
                  <th className="text-left p-2">Use case</th>
                </tr>
              </thead>
              <tbody>
                {quant.data.table.map((q: any) => (
                  <tr key={q.name} className={`border-t border-bg-border ${q.name === quant.data!.primary ? "bg-nv-500/5" : ""}`}>
                    <td className="p-2 font-mono">{q.name}</td>
                    <td className="p-2 text-right">{q.bits_per_weight}</td>
                    <td className="p-2 text-right">{q.quality}/10</td>
                    <td className="p-2 text-right">{q.speed}/10</td>
                    <td className="p-2 text-right">{fmtMb(q.expected_vram_mb_for_7b)}</td>
                    <td className="p-2 text-text-muted">{q.use_case}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="card p-5 space-y-4">
        <h3 className="font-semibold flex items-center gap-2"><Sliders className="w-4 h-4" /> Config search</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div>
            <div className="stat-label">Goal</div>
            <Select value={goal} onChange={(e) => setGoal(e.target.value as Goal)}>
              <option value="balanced">Balanced</option>
              <option value="fastest">Fastest</option>
              <option value="lowest_memory">Lowest memory</option>
              <option value="most_stable">Most stable</option>
              <option value="best_quality">Best quality</option>
            </Select>
          </div>
          <div className="md:col-span-2 flex items-end">
            <Button onClick={() => optimize.mutate()} disabled={optimize.isPending || !config.model_path}>
              {optimize.isPending ? "Searching…" : "Find best config"}
            </Button>
          </div>
        </div>

        {result && (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-3">
            {[
              { key: "fastest", icon: <Zap className="w-3.5 h-3.5" />, label: "Fastest" },
              { key: "balanced", icon: <Sliders className="w-3.5 h-3.5" />, label: "Balanced" },
              { key: "lowest_memory", icon: <MemoryStick className="w-3.5 h-3.5" />, label: "Lowest memory" },
              { key: "most_stable", icon: <Shield className="w-3.5 h-3.5" />, label: "Most stable" },
            ].map(({ key, icon, label }) => {
              const c = result[key];
              if (!c) return null;
              return (
                <div key={key} className="rounded-lg bg-bg-elevated border border-bg-border p-3 space-y-2">
                  <div className="flex items-center gap-2 stat-label">{icon}{label}</div>
                  <div className="text-lg font-semibold">{fmtNumber(c.benchmark?.token_gen_tps, 1)} t/s</div>
                  <div className="text-xs text-text-muted">{c.rationale}</div>
                  <div className="text-xs font-mono">VRAM {fmtMb(c.benchmark?.peak_vram_mb)} · Temp {fmtNumber(c.benchmark?.peak_temperature_c, 0)}°C</div>
                  <Button size="sm" variant="outline" onClick={() => setConfig(c.config)}>Apply</Button>
                </div>
              );
            })}
          </div>
        )}

        {!config.model_path && (
          <div className="text-xs text-yellow-300">Set a model path in Configuration before running search.</div>
        )}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Stat label="Detected GPU" value={hw?.gpus?.[0]?.name ?? "—"} />
        <Stat label="Total VRAM" value={fmtMb(vram)} />
        <Stat label="Jetson" value={isJetson ? "Yes" : "No"} />
      </div>
    </div>
  );
}
