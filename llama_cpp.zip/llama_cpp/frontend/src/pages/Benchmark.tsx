import { useMutation, useQuery } from "@tanstack/react-query";
import { Play, Activity } from "lucide-react";
import { api, type BenchmarkResult } from "@/lib/api";
import { useConfigStore } from "@/store/config";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Stat } from "@/components/Stat";
import { fmtMb, fmtNumber } from "@/lib/utils";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip as RTooltip } from "recharts";

export function BenchmarkPage() {
  const config = useConfigStore((s) => s.config);

  const { data: history, refetch } = useQuery({
    queryKey: ["benchmarks"],
    queryFn: () => api.get<BenchmarkResult[]>("/api/benchmark/history?limit=20"),
  });

  const start = useMutation({
    mutationFn: () => api.post<BenchmarkResult>("/api/benchmark/start", { config, prompt: "Explain quantum entanglement to a 10 year old. " + "Detail. ".repeat(20), n_predict: 128, label: `manual ${new Date().toLocaleTimeString()}` }),
    onSuccess: () => refetch(),
  });

  const last = history?.[history.length - 1];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Benchmark"
        subtitle="Measure throughput, latency, VRAM, GPU utilisation, and thermals on your current configuration."
        actions={
          <Button onClick={() => start.mutate()} disabled={start.isPending || !config.model_path}>
            <Play className="w-4 h-4" /> {start.isPending ? "Running…" : "Run benchmark"}
          </Button>
        }
      />

      {!config.model_path && (
        <div className="card p-3 text-sm text-yellow-300">
          Set a model path in <strong>Configuration</strong> first.
        </div>
      )}

      {start.error && (
        <div className="card p-3 text-sm text-red-300">{(start.error as Error).message}</div>
      )}

      {last && (
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
          <Stat label="Token gen" value={`${fmtNumber(last.token_gen_tps, 1)} t/s`} icon={<Activity className="w-3.5 h-3.5" />} />
          <Stat label="Prompt eval" value={`${fmtNumber(last.prompt_eval_tps, 1)} t/s`} />
          <Stat label="Peak VRAM" value={fmtMb(last.peak_vram_mb)} />
          <Stat label="Latency (1st token)" value={last.latency_first_token_ms ? `${fmtNumber(last.latency_first_token_ms, 0)} ms` : "—"} />
        </div>
      )}

      <div className="card p-5">
        <h3 className="font-semibold mb-3">Throughput history</h3>
        <div className="h-64">
          <ResponsiveContainer>
            <BarChart data={(history ?? []).map((h, i) => ({ idx: i + 1, tps: h.token_gen_tps, vram: h.peak_vram_mb || 0 }))}>
              <XAxis dataKey="idx" tick={{ fill: "#94a3b8", fontSize: 11 }} />
              <YAxis tick={{ fill: "#94a3b8", fontSize: 11 }} />
              <RTooltip contentStyle={{ background: "#171d23", border: "1px solid #222a31", borderRadius: 8 }} />
              <Bar dataKey="tps" fill="#76b900" name="tokens/sec" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="card p-0 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-bg-elevated text-text-muted text-xs uppercase tracking-wider">
            <tr>
              <th className="text-left p-3">When</th>
              <th className="text-left p-3">Label</th>
              <th className="text-right p-3">Token gen</th>
              <th className="text-right p-3">Prompt eval</th>
              <th className="text-right p-3">VRAM</th>
              <th className="text-right p-3">Temp</th>
              <th className="text-right p-3">Time</th>
              <th className="text-right p-3">Status</th>
            </tr>
          </thead>
          <tbody>
            {(history ?? []).slice().reverse().map((b) => (
              <tr key={b.id} className="border-t border-bg-border">
                <td className="p-3 text-text-muted">{b.created_at?.slice(0, 19).replace("T", " ")}</td>
                <td className="p-3">{b.label ?? "—"}</td>
                <td className="p-3 text-right font-mono">{fmtNumber(b.token_gen_tps, 1)}</td>
                <td className="p-3 text-right font-mono">{fmtNumber(b.prompt_eval_tps, 1)}</td>
                <td className="p-3 text-right font-mono">{fmtMb(b.peak_vram_mb)}</td>
                <td className="p-3 text-right font-mono">{b.peak_temperature_c ? `${fmtNumber(b.peak_temperature_c, 0)} °C` : "—"}</td>
                <td className="p-3 text-right font-mono">{fmtNumber(b.total_seconds, 1)}s</td>
                <td className="p-3 text-right">
                  {b.success ? <span className="text-nv-300">ok</span> : <span className="text-red-300">{b.error}</span>}
                </td>
              </tr>
            ))}
            {(history?.length ?? 0) === 0 && (
              <tr><td colSpan={8} className="p-6 text-center text-text-muted">No benchmarks yet — run one above.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
