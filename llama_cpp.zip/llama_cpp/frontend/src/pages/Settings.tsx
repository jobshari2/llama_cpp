import { useEffect, useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Save } from "lucide-react";
import { api } from "@/lib/api";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";

type AppSettings = {
  llama_cli_path?: string | null;
  llama_server_path?: string | null;
  default_models_dir?: string | null;
  huggingface_token?: string | null;
  theme: "dark" | "light";
  advanced_mode: boolean;
};

export function SettingsPage() {
  const [form, setForm] = useState<AppSettings>({ theme: "dark", advanced_mode: false });

  const { data } = useQuery({
    queryKey: ["settings"],
    queryFn: () => api.get<AppSettings>("/api/config/settings"),
  });
  useEffect(() => { if (data) setForm(data); }, [data]);

  const { data: ver } = useQuery({
    queryKey: ["llama-version"],
    queryFn: () => api.get<{ binary: string | null; version: string | null }>("/api/config/llama-version"),
  });

  const save = useMutation({
    mutationFn: () => api.put<AppSettings>("/api/config/settings", form),
  });

  return (
    <div className="space-y-6 max-w-3xl">
      <PageHeader
        title="Settings"
        subtitle="Binary paths, Hugging Face token, and UI preferences."
        actions={<Button onClick={() => save.mutate()} disabled={save.isPending}><Save className="w-4 h-4" /> Save</Button>}
      />

      <div className="card p-5 space-y-3">
        <div>
          <div className="stat-label mb-1">llama-cli binary</div>
          <Input value={form.llama_cli_path ?? ""} onChange={(e) => setForm({ ...form, llama_cli_path: e.target.value || null })} placeholder="auto-discovered if blank" />
          <div className="text-xs text-text-muted mt-1">
            Detected: {ver?.binary ? <span className="font-mono">{ver.binary}</span> : <Badge variant="warn">not found</Badge>}
            {ver?.version && <span className="ml-2 text-text-subtle">{ver.version}</span>}
          </div>
        </div>
        <div>
          <div className="stat-label mb-1">llama-server binary</div>
          <Input value={form.llama_server_path ?? ""} onChange={(e) => setForm({ ...form, llama_server_path: e.target.value || null })} />
        </div>
        <div>
          <div className="stat-label mb-1">Default models dir</div>
          <Input value={form.default_models_dir ?? ""} onChange={(e) => setForm({ ...form, default_models_dir: e.target.value || null })} />
        </div>
        <div>
          <div className="stat-label mb-1">Hugging Face token</div>
          <Input type="password" value={form.huggingface_token ?? ""} onChange={(e) => setForm({ ...form, huggingface_token: e.target.value || null })} />
        </div>
        <label className="flex items-center gap-2 text-sm pt-2">
          <Switch checked={form.advanced_mode} onCheckedChange={(v) => setForm({ ...form, advanced_mode: v })} />
          Advanced mode (show expert explanations by default)
        </label>
      </div>
    </div>
  );
}
