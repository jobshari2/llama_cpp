import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Cpu, MemoryStick, Thermometer, Zap, Activity, HardDrive, Server } from "lucide-react";
import { api, type HardwareSnapshot } from "@/lib/api";
import { PageHeader } from "@/components/PageHeader";
import { Stat } from "@/components/Stat";
import { Badge } from "@/components/ui/badge";
import { fmtMb, fmtNumber } from "@/lib/utils";
import { LineChart, Line, ResponsiveContainer, XAxis, YAxis, Tooltip as RTooltip } from "recharts";

type Series = { t: number; vram: number; gpu: number; temp: number }[];

export function Dashboard() {
  const [series, setSeries] = useState<Series>([]);

  const { data: hw } = useQuery<HardwareSnapshot>({
    queryKey: ["hardware"],
    queryFn: () => api.get<HardwareSnapshot>("/api/hardware/latest"),
  });

  useEffect(() => {
    const ws = new WebSocket(`${location.protocol === "https:" ? "wss" : "ws"}://${location.host}/api/dashboard/live`);
    ws.onmessage = (ev) => {
      const snap: HardwareSnapshot = JSON.parse(ev.data);
      const g = snap.gpus[0];
      setSeries((s) => [
        ...s.slice(-59),
        {
          t: Date.now(),
          vram: g?.vram_used_mb ?? 0,
          gpu: g?.utilization_percent ?? 0,
          temp: g?.temperature_c ?? 0,
        },
      ]);
    };
    return () => ws.close();
  }, []);

  const gpu = hw?.gpus?.[0];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Dashboard"
        subtitle="Live hardware overview, current model, and the most recent benchmarks."
        actions={
          hw?.jetson?.is_jetson ? (
            <Badge variant="success">Jetson · {hw.jetson.model || "detected"}</Badge>
          ) : null
        }
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <Stat
          label="GPU"
          value={gpu?.name ?? "No NVIDIA GPU"}
          hint={gpu?.compute_capability ? `Compute ${gpu.compute_capability}` : undefined}
          icon={<Server className="w-3.5 h-3.5" />}
        />
        <Stat
          label="VRAM"
          value={gpu ? `${fmtMb(gpu.vram_used_mb)} / ${fmtMb(gpu.vram_total_mb)}` : "—"}
          hint={gpu ? `${Math.round((gpu.vram_used_mb / gpu.vram_total_mb) * 100)}% used` : undefined}
          icon={<MemoryStick className="w-3.5 h-3.5" />}
        />
        <Stat
          label="GPU Utilisation"
          value={gpu ? `${fmtNumber(gpu.utilization_percent ?? 0, 0)}%` : "—"}
          hint={gpu?.power_w ? `${fmtNumber(gpu.power_w)} W` : undefined}
          icon={<Activity className="w-3.5 h-3.5" />}
        />
        <Stat
          label="Temperature"
          value={gpu?.temperature_c != null ? `${fmtNumber(gpu.temperature_c, 0)} °C` : "—"}
          hint={gpu?.temperature_c && gpu.temperature_c > 80 ? "⚠ throttling soon" : undefined}
          icon={<Thermometer className="w-3.5 h-3.5" />}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="card p-5 lg:col-span-2">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold flex items-center gap-2"><Activity className="w-4 h-4" /> GPU Utilisation & VRAM</h3>
            <span className="text-xs text-text-subtle">Live · 60s window</span>
          </div>
          <div className="h-56">
            <ResponsiveContainer>
              <LineChart data={series.map((p) => ({ ...p, ts: new Date(p.t).toLocaleTimeString() }))}>
                <XAxis dataKey="ts" hide />
                <YAxis yAxisId="left" tick={{ fill: "#94a3b8", fontSize: 11 }} />
                <YAxis yAxisId="right" orientation="right" tick={{ fill: "#94a3b8", fontSize: 11 }} />
                <RTooltip
                  contentStyle={{ background: "#171d23", border: "1px solid #222a31", borderRadius: 8 }}
                  labelStyle={{ color: "#94a3b8" }}
                />
                <Line yAxisId="left" type="monotone" dataKey="gpu" stroke="#76b900" dot={false} strokeWidth={2} name="GPU %" />
                <Line yAxisId="right" type="monotone" dataKey="vram" stroke="#34c759" dot={false} strokeWidth={2} name="VRAM (MB)" />
                <Line yAxisId="left" type="monotone" dataKey="temp" stroke="#fb923c" dot={false} strokeWidth={1.5} strokeDasharray="3 3" name="Temp °C" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="card p-5 space-y-3">
          <h3 className="font-semibold flex items-center gap-2"><Cpu className="w-4 h-4" /> CPU & RAM</h3>
          <div>
            <div className="stat-label">CPU</div>
            <div className="text-sm">{hw?.cpu?.model ?? "—"}</div>
            <div className="text-xs text-text-muted">{hw?.cpu?.physical_cores} physical / {hw?.cpu?.logical_cores} logical</div>
          </div>
          <div>
            <div className="stat-label">Load</div>
            <div className="text-sm">{fmtNumber(hw?.cpu?.load_percent ?? 0, 0)}%</div>
          </div>
          <div>
            <div className="stat-label flex items-center gap-1"><MemoryStick className="w-3 h-3" /> RAM</div>
            <div className="text-sm">{fmtMb(hw?.memory?.used_mb)} used / {fmtMb(hw?.memory?.total_mb)}</div>
          </div>
          {hw?.memory?.swap_total_mb ? (
            <div>
              <div className="stat-label">Swap</div>
              <div className="text-sm">{fmtMb(hw.memory.swap_total_mb - hw.memory.swap_free_mb)} / {fmtMb(hw.memory.swap_total_mb)}</div>
            </div>
          ) : null}
        </div>
      </div>

      <div className="card p-5">
        <h3 className="font-semibold flex items-center gap-2 mb-3"><HardDrive className="w-4 h-4" /> Storage</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {hw?.storage?.devices?.map((d) => (
            <div key={d.mount} className="rounded-lg bg-bg-elevated border border-bg-border p-3">
              <div className="font-mono text-xs">{d.mount}</div>
              <div className="text-sm mt-1">{d.free_gb.toFixed(1)} / {d.total_gb.toFixed(1)} GB free</div>
              <div className="flex gap-1 mt-2">
                {d.is_nvme && <Badge variant="success">NVMe</Badge>}
                {d.is_ssd && !d.is_nvme && <Badge variant="success">SSD</Badge>}
                {d.fstype && <Badge variant="outline">{d.fstype}</Badge>}
              </div>
            </div>
          ))}
        </div>
      </div>

      {hw?.jetson?.is_jetson && (
        <div className="card p-5">
          <h3 className="font-semibold flex items-center gap-2 mb-3"><Zap className="w-4 h-4" /> Jetson</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
            <div><div className="stat-label">Model</div>{hw.jetson.model ?? "—"}</div>
            <div><div className="stat-label">JetPack</div>{hw.jetson.jetpack_version ?? "—"}</div>
            <div><div className="stat-label">nvpmodel</div>{hw.jetson.nvpmodel ?? "—"}</div>
            <div><div className="stat-label">jetson_clocks</div>{String(hw.jetson.jetson_clocks_active ?? "?")}</div>
          </div>
        </div>
      )}
    </div>
  );
}
