import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Star, RefreshCw, Download, FolderOpen } from "lucide-react";
import { api, type ModelRecord } from "@/lib/api";
import { useConfigStore } from "@/store/config";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { fmtBytes, fmtMb } from "@/lib/utils";

export function Models() {
  const qc = useQueryClient();
  const setConfig = useConfigStore((s) => s.setConfig);
  const config = useConfigStore((s) => s.config);
  const [repo, setRepo] = useState("TheBloke/Llama-2-7B-Chat-GGUF");
  const [filename, setFilename] = useState("llama-2-7b-chat.Q4_K_M.gguf");

  const { data: models } = useQuery({
    queryKey: ["models"],
    queryFn: () => api.get<ModelRecord[]>("/api/models"),
  });

  const scan = useMutation({
    mutationFn: () => api.post<ModelRecord[]>("/api/models/scan"),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["models"] }),
  });
  const dl = useMutation({
    mutationFn: (body: { repo_id: string; filename: string }) => api.post<ModelRecord>("/api/models/download", body),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["models"] }),
  });
  const fav = useMutation({
    mutationFn: (m: ModelRecord) => api.post<ModelRecord>(`/api/models/${m.id}/favorite?value=${!m.favorite}`),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["models"] }),
  });

  return (
    <div className="space-y-6">
      <PageHeader
        title="Models"
        subtitle="GGUF models discovered on disk and downloaded from Hugging Face."
        actions={
          <Button variant="outline" onClick={() => scan.mutate()} disabled={scan.isPending}>
            <RefreshCw className={`w-4 h-4 ${scan.isPending ? "animate-spin" : ""}`} /> Scan
          </Button>
        }
      />

      <div className="card p-5 space-y-3">
        <h3 className="font-semibold flex items-center gap-2"><Download className="w-4 h-4" /> Hugging Face download</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          <Input value={repo} onChange={(e) => setRepo(e.target.value)} placeholder="repo_id (e.g. TheBloke/Llama-2-7B-Chat-GGUF)" />
          <Input value={filename} onChange={(e) => setFilename(e.target.value)} placeholder="filename (e.g. llama-2-7b-chat.Q4_K_M.gguf)" />
        </div>
        <div>
          <Button onClick={() => dl.mutate({ repo_id: repo, filename })} disabled={dl.isPending}>
            <Download className="w-4 h-4" /> {dl.isPending ? "Downloading…" : "Download"}
          </Button>
          {dl.error && <div className="text-xs text-red-300 mt-2">{(dl.error as Error).message}</div>}
        </div>
      </div>

      <div className="card p-0 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-bg-elevated text-text-muted text-xs uppercase tracking-wider">
            <tr>
              <th className="text-left p-3"></th>
              <th className="text-left p-3">Name</th>
              <th className="text-left p-3">Path</th>
              <th className="text-left p-3">Quant</th>
              <th className="text-right p-3">Size</th>
              <th className="text-right p-3">~VRAM</th>
              <th className="text-right p-3"></th>
            </tr>
          </thead>
          <tbody>
            {(models ?? []).map((m) => (
              <tr key={m.id} className="border-t border-bg-border">
                <td className="p-3">
                  <button onClick={() => fav.mutate(m)} title="Favorite">
                    <Star className={`w-4 h-4 ${m.favorite ? "fill-nv-500 text-nv-500" : "text-text-subtle"}`} />
                  </button>
                </td>
                <td className="p-3 font-medium">{m.name}</td>
                <td className="p-3 text-text-muted truncate max-w-[24rem]">
                  <FolderOpen className="w-3.5 h-3.5 inline mr-1 -mt-0.5" />
                  <span className="font-mono text-xs">{m.path}</span>
                </td>
                <td className="p-3"><Badge variant="success">{m.quantization ?? "?"}</Badge></td>
                <td className="p-3 text-right font-mono">{fmtBytes(m.size_bytes)}</td>
                <td className="p-3 text-right font-mono">{fmtMb(m.estimated_vram_mb)}</td>
                <td className="p-3 text-right">
                  <Button
                    size="sm"
                    variant={config.model_path === m.path ? "default" : "outline"}
                    onClick={() => setConfig({ ...config, model_path: m.path })}
                  >
                    {config.model_path === m.path ? "Selected" : "Use"}
                  </Button>
                </td>
              </tr>
            ))}
            {(models?.length ?? 0) === 0 && (
              <tr><td colSpan={7} className="p-6 text-center text-text-muted">No models yet — scan or download above.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
