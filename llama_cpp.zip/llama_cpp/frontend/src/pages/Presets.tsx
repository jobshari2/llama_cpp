import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Trash2, Save, CheckCircle2 } from "lucide-react";
import { api, type Preset } from "@/lib/api";
import { useConfigStore } from "@/store/config";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export function Presets() {
  const qc = useQueryClient();
  const setConfig = useConfigStore((s) => s.setConfig);
  const currentConfig = useConfigStore((s) => s.config);

  const { data: presets } = useQuery({
    queryKey: ["presets"],
    queryFn: () => api.get<Preset[]>("/api/presets"),
  });

  const save = useMutation({
    mutationFn: () =>
      api.post<Preset>("/api/presets", {
        name: `Custom ${new Date().toLocaleString()}`,
        description: "Saved from Configuration",
        tags: ["custom"],
        config: currentConfig,
        builtin: false,
      }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["presets"] }),
  });
  const del = useMutation({
    mutationFn: (id: string) => api.del(`/api/presets/${id}`),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["presets"] }),
  });

  return (
    <div className="space-y-6">
      <PageHeader
        title="Presets"
        subtitle="Built-in and saved configurations. Apply with one click."
        actions={
          <Button onClick={() => save.mutate()} disabled={save.isPending}>
            <Save className="w-4 h-4" /> Save current as preset
          </Button>
        }
      />

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {(presets ?? []).map((p) => (
          <div key={p.id} className="card card-hover p-5 flex flex-col gap-3">
            <div className="flex items-start justify-between">
              <div>
                <div className="font-semibold flex items-center gap-2">
                  {p.name}
                  {p.builtin ? <Badge variant="success">built-in</Badge> : <Badge variant="outline">custom</Badge>}
                </div>
                <p className="text-sm text-text-muted mt-1">{p.description}</p>
              </div>
            </div>
            <div className="flex flex-wrap gap-1">
              {p.tags.map((t) => <Badge key={t}>{t}</Badge>)}
            </div>
            <div className="text-xs font-mono text-text-muted">
              ngl: {p.config.gpu_layers} · fa: {String(p.config.flash_attn)} · ctx: {p.config.ctx_size} ·
              kv: {p.config.cache_type_k}/{p.config.cache_type_v}
            </div>
            <div className="mt-auto flex items-center justify-between">
              <Button
                onClick={() => setConfig({ ...p.config, model_path: currentConfig.model_path || p.config.model_path })}
              >
                <CheckCircle2 className="w-4 h-4" /> Apply
              </Button>
              {!p.builtin && (
                <Button variant="ghost" size="icon" onClick={() => p.id && del.mutate(p.id)}>
                  <Trash2 className="w-4 h-4 text-red-300" />
                </Button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
