import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Rocket, Wrench } from "lucide-react";
import { api } from "@/lib/api";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";

export function TensorRT() {
  const { data: detect } = useQuery({
    queryKey: ["trt-detect"],
    queryFn: () => api.get<any>("/api/tensorrt/detect"),
  });
  const { data: engines, refetch: refetchEngines } = useQuery({
    queryKey: ["trt-engines"],
    queryFn: () => api.get<any[]>("/api/tensorrt/engines"),
  });

  const [plan, setPlan] = useState({
    checkpoint_dir: "",
    output_dir: "",
    precision: "float16",
    max_batch_size: 8,
    max_input_len: 2048,
    max_output_len: 512,
    paged_kv_cache: true,
    use_fused_mlp: true,
  });

  const planM = useMutation({
    mutationFn: () => api.post<{ command: string[] }>("/api/tensorrt/plan-build", plan),
  });
  const register = useMutation({
    mutationFn: (body: any) => api.post("/api/tensorrt/engines", body),
    onSuccess: () => refetchEngines(),
  });

  return (
    <div className="space-y-6">
      <PageHeader
        title="TensorRT-LLM"
        subtitle="Build and manage TensorRT-LLM engines, then compare performance against llama.cpp."
        actions={
          detect?.available
            ? <Badge variant="success">trtllm-build detected</Badge>
            : <Badge variant="warn">trtllm-build not on PATH</Badge>
        }
      />

      <div className="card p-5 space-y-3">
        <h3 className="font-semibold flex items-center gap-2"><Wrench className="w-4 h-4" /> Detection</h3>
        <pre className="text-xs font-mono text-text-muted whitespace-pre-wrap break-all">
          {JSON.stringify(detect ?? {}, null, 2)}
        </pre>
      </div>

      <div className="card p-5 space-y-4">
        <h3 className="font-semibold flex items-center gap-2"><Rocket className="w-4 h-4" /> Build wizard</h3>
        <p className="text-sm text-text-muted">
          Fill in fields then preview the <code>trtllm-build</code> command. Run it manually in your TensorRT-LLM environment.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <Field label="Checkpoint dir"><Input value={plan.checkpoint_dir} onChange={(e) => setPlan({ ...plan, checkpoint_dir: e.target.value })} /></Field>
          <Field label="Output dir"><Input value={plan.output_dir} onChange={(e) => setPlan({ ...plan, output_dir: e.target.value })} /></Field>
          <Field label="Precision">
            <Select value={plan.precision} onChange={(e) => setPlan({ ...plan, precision: e.target.value })}>
              <option value="float16">float16</option>
              <option value="bfloat16">bfloat16</option>
              <option value="float32">float32</option>
              <option value="int8">int8</option>
            </Select>
          </Field>
          <Field label="Max batch size"><Input type="number" value={plan.max_batch_size} onChange={(e) => setPlan({ ...plan, max_batch_size: Number(e.target.value) })} /></Field>
          <Field label="Max input len"><Input type="number" value={plan.max_input_len} onChange={(e) => setPlan({ ...plan, max_input_len: Number(e.target.value) })} /></Field>
          <Field label="Max output len"><Input type="number" value={plan.max_output_len} onChange={(e) => setPlan({ ...plan, max_output_len: Number(e.target.value) })} /></Field>
          <Field label="Paged KV cache"><Switch checked={plan.paged_kv_cache} onCheckedChange={(v) => setPlan({ ...plan, paged_kv_cache: v })} /></Field>
          <Field label="Fused MLP"><Switch checked={plan.use_fused_mlp} onCheckedChange={(v) => setPlan({ ...plan, use_fused_mlp: v })} /></Field>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => planM.mutate()}>Generate command</Button>
          <Button variant="outline" onClick={() => register.mutate({
            name: plan.output_dir.split(/[\\/]/).pop() || "engine",
            path: plan.output_dir,
            precision: plan.precision,
            source_model: plan.checkpoint_dir,
          })}>Register engine</Button>
        </div>
        {planM.data && (
          <pre className="bg-bg-elevated border border-bg-border rounded-md p-3 text-xs font-mono whitespace-pre-wrap break-all">
            {planM.data.command.join(" ")}
          </pre>
        )}
      </div>

      <div className="card p-5">
        <h3 className="font-semibold mb-3">Registered engines</h3>
        <div className="space-y-2">
          {(engines ?? []).map((e: any) => (
            <div key={e.id} className="rounded-lg bg-bg-elevated border border-bg-border p-3 text-sm font-mono flex items-center justify-between">
              <div>
                <div className="font-semibold">{e.name}</div>
                <div className="text-xs text-text-muted">{e.path}</div>
              </div>
              <div className="flex gap-2 items-center">
                <Badge variant="outline">{e.precision}</Badge>
                <Badge variant={e.exists ? "success" : "danger"}>{e.exists ? "exists" : "missing"}</Badge>
              </div>
            </div>
          ))}
          {(engines?.length ?? 0) === 0 && <div className="text-sm text-text-muted">No engines registered yet.</div>}
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <div className="stat-label mb-1">{label}</div>
      {children}
    </label>
  );
}
