import { useEffect, useRef, useState } from "react";
import { Send, Square } from "lucide-react";
import { useConfigStore } from "@/store/config";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Stat } from "@/components/Stat";
import { fmtMb, fmtNumber } from "@/lib/utils";

type Metrics = { tps?: number; vram?: number; gpu?: number; temp?: number; tokens?: number };

export function Playground() {
  const config = useConfigStore((s) => s.config);
  const [prompt, setPrompt] = useState("Write a one-sentence haiku about an LLM running on a Jetson Orin Nano.");
  const [output, setOutput] = useState("");
  const [running, setRunning] = useState(false);
  const [metrics, setMetrics] = useState<Metrics>({});
  const wsRef = useRef<WebSocket | null>(null);
  const outRef = useRef<HTMLPreElement>(null);

  useEffect(() => {
    if (outRef.current) outRef.current.scrollTop = outRef.current.scrollHeight;
  }, [output]);

  const stop = () => {
    wsRef.current?.close();
    setRunning(false);
  };

  const send = () => {
    if (!config.model_path) return;
    setOutput("");
    setMetrics({});
    setRunning(true);
    const ws = new WebSocket(`${location.protocol === "https:" ? "wss" : "ws"}://${location.host}/api/inference/stream`);
    wsRef.current = ws;
    ws.onopen = () => ws.send(JSON.stringify({ config, prompt }));
    ws.onmessage = (ev) => {
      const msg = JSON.parse(ev.data);
      if (msg.event === "token") setOutput((s) => s + msg.chunk);
      else if (msg.event === "metrics") {
        setMetrics({
          tps: msg.tps_estimate,
          vram: msg.vram_mb,
          gpu: msg.gpu_util,
          temp: msg.temp_c,
          tokens: msg.approx_tokens,
        });
      } else if (msg.event === "done" || msg.event === "error") {
        setRunning(false);
        if (msg.event === "error") setOutput((s) => s + `\n\n[error] ${msg.error}`);
      }
    };
    ws.onclose = () => setRunning(false);
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Playground"
        subtitle="Streaming inference with live tokens/sec, GPU utilisation, and VRAM."
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <Stat label="Tokens/sec (est)" value={fmtNumber(metrics.tps, 1)} />
        <Stat label="VRAM" value={fmtMb(metrics.vram)} />
        <Stat label="GPU util" value={metrics.gpu != null ? `${fmtNumber(metrics.gpu, 0)}%` : "—"} />
        <Stat label="Tokens" value={metrics.tokens ?? 0} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="card p-5 lg:col-span-2 space-y-3">
          <textarea
            className="w-full h-32 bg-bg-elevated border border-bg-border rounded-md p-3 text-sm font-mono"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
          />
          <div className="flex gap-2">
            {!running ? (
              <Button onClick={send} disabled={!config.model_path}>
                <Send className="w-4 h-4" /> Run
              </Button>
            ) : (
              <Button variant="destructive" onClick={stop}>
                <Square className="w-4 h-4" /> Stop
              </Button>
            )}
          </div>
          {!config.model_path && (
            <div className="text-xs text-yellow-300">Set a model path in Configuration first.</div>
          )}
        </div>

        <div className="card p-5 space-y-2">
          <div className="text-xs text-text-subtle uppercase tracking-wider">Active config</div>
          <div className="text-xs space-y-1 font-mono">
            <div>model: <span className="text-nv-300">{config.model_path.split(/[\\/]/).pop() || "—"}</span></div>
            <div>ngl: {config.gpu_layers} · fa: {String(config.flash_attn)} · ctx: {config.ctx_size}</div>
            <div>batch: {config.batch_size} · ubatch: {config.ubatch_size}</div>
            <div>kv: {config.cache_type_k}/{config.cache_type_v}</div>
            <div>temp: {config.temperature} · top-p: {config.top_p}</div>
          </div>
        </div>
      </div>

      <div className="card p-5">
        <h3 className="font-semibold mb-2">Output</h3>
        <pre
          ref={outRef}
          className="bg-bg-elevated border border-bg-border rounded-md p-4 h-80 overflow-auto whitespace-pre-wrap text-sm font-mono"
        >
          {output || (running ? "Waiting for first token…" : "—")}
        </pre>
      </div>
    </div>
  );
}
