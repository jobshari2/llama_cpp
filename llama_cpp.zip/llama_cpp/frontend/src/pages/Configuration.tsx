import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Info, AlertTriangle } from "lucide-react";
import { api, type ParamMeta, type LlamaConfig } from "@/lib/api";
import { useConfigStore } from "@/store/config";
import { PageHeader } from "@/components/PageHeader";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";

const IMPACT_BADGE: Record<string, "default" | "outline" | "warn" | "danger" | "success"> = {
  none: "outline",
  low: "outline",
  medium: "warn",
  high: "danger",
};

export function Configuration() {
  const [advanced, setAdvanced] = useState(false);
  const config = useConfigStore((s) => s.config);
  const patch = useConfigStore((s) => s.patch);
  const reset = useConfigStore((s) => s.reset);

  const { data: groups } = useQuery({
    queryKey: ["params"],
    queryFn: () => api.get<Record<string, ParamMeta[]>>("/api/config/parameters/grouped"),
  });

  const { data: preview, refetch: refetchPreview } = useQuery({
    queryKey: ["preview", config],
    queryFn: () => api.post<{ command?: string; error?: string }>("/api/config/preview", config),
    enabled: false,
  });

  return (
    <div className="space-y-6">
      <PageHeader
        title="Configuration"
        subtitle="Every llama.cpp parameter, with plain-English explanations and impact estimates."
        actions={
          <>
            <label className="flex items-center gap-2 text-xs text-text-muted">
              <Switch checked={advanced} onCheckedChange={setAdvanced} />
              Advanced mode
            </label>
            <Button variant="outline" onClick={reset}>Reset</Button>
            <Button onClick={() => refetchPreview()}>Preview command</Button>
          </>
        }
      />

      <div className="card p-3 -mt-2">
        <Input
          placeholder="Model path (e.g. D:\\models\\llama-3.1-8b-instruct.Q4_K_M.gguf)"
          value={config.model_path}
          onChange={(e) => patch("model_path", e.target.value)}
        />
      </div>

      {preview?.command && (
        <pre className="card p-3 text-xs font-mono whitespace-pre-wrap break-all overflow-x-auto">
          {preview.command}
        </pre>
      )}
      {preview?.error && (
        <div className="card p-3 text-xs flex items-start gap-2 text-yellow-300">
          <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
          <span>{preview.error}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {groups &&
          Object.entries(groups).map(([group, params]) => (
            <div key={group} className="card p-5">
              <h3 className="font-semibold capitalize mb-3">{group}</h3>
              <div className="space-y-4">
                {params.map((p) => (
                  <ParamControl key={p.flag} meta={p} config={config} patch={patch} advanced={advanced} />
                ))}
              </div>
            </div>
          ))}
      </div>
    </div>
  );
}

function ParamControl({
  meta, config, patch, advanced,
}: {
  meta: ParamMeta;
  config: LlamaConfig;
  patch: <K extends keyof LlamaConfig>(k: K, v: LlamaConfig[K]) => void;
  advanced: boolean;
}) {
  const flagToKey = mapFlagToKey(meta.flag);
  if (!flagToKey) return null;
  const value = (config as any)[flagToKey];

  return (
    <div className="border-b border-bg-border last:border-0 pb-3 last:pb-0">
      <div className="flex items-start justify-between gap-3 mb-1.5">
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium">{meta.name}</span>
            <code className="text-[11px] text-text-subtle font-mono">{meta.flag}</code>
            <Tooltip>
              <TooltipTrigger asChild>
                <Info className="w-3.5 h-3.5 text-text-subtle hover:text-nv-400 cursor-help" />
              </TooltipTrigger>
              <TooltipContent side="top" className="max-w-sm">
                <div className="font-medium mb-1">{meta.name}</div>
                <div className="text-text-muted mb-1.5">{meta.beginner}</div>
                {advanced && <div className="text-text-subtle italic">{meta.advanced}</div>}
              </TooltipContent>
            </Tooltip>
          </div>
          {!advanced && <div className="text-xs text-text-muted mt-0.5">{meta.beginner}</div>}
          <div className="flex flex-wrap gap-1 mt-1.5">
            {meta.perf_impact !== "none" && <Badge variant={IMPACT_BADGE[meta.perf_impact] as never}>perf {meta.perf_impact}</Badge>}
            {meta.vram_impact !== "none" && <Badge variant={IMPACT_BADGE[meta.vram_impact] as never}>vram {meta.vram_impact}</Badge>}
            {meta.latency_impact !== "none" && <Badge variant={IMPACT_BADGE[meta.latency_impact] as never}>latency {meta.latency_impact}</Badge>}
            {meta.risk !== "none" && <Badge variant="warn">risk {meta.risk}</Badge>}
          </div>
        </div>
        <div className={cn("min-w-[140px] flex items-center justify-end")}>
          {renderInput(meta, value, (v) => patch(flagToKey as any, v as never))}
        </div>
      </div>
    </div>
  );
}

function renderInput(meta: ParamMeta, value: any, onChange: (v: any) => void) {
  if (meta.type === "bool") {
    return <Switch checked={!!value} onCheckedChange={(v) => onChange(v)} />;
  }
  if (meta.type === "enum" && meta.enum) {
    return (
      <Select value={String(value ?? "")} onChange={(e) => onChange(e.target.value)}>
        {meta.enum.map((opt) => (
          <option key={opt} value={opt}>{opt}</option>
        ))}
      </Select>
    );
  }
  if (meta.type === "int" || meta.type === "float") {
    return (
      <Input
        type="number"
        className="w-32"
        step={meta.type === "float" ? 0.01 : 1}
        min={meta.minimum ?? undefined}
        max={meta.maximum ?? undefined}
        value={value ?? ""}
        onChange={(e) => onChange(meta.type === "int" ? Number.parseInt(e.target.value || "0", 10) : Number.parseFloat(e.target.value || "0"))}
      />
    );
  }
  return (
    <Input className="w-44" value={value ?? ""} onChange={(e) => onChange(e.target.value || null)} />
  );
}

function mapFlagToKey(flag: string): keyof LlamaConfig | null {
  const m: Record<string, keyof LlamaConfig> = {
    "--threads": "threads",
    "--ctx-size": "ctx_size",
    "--batch-size": "batch_size",
    "--ubatch-size": "ubatch_size",
    "--n-predict": "n_predict",
    "--gpu-layers": "gpu_layers",
    "--main-gpu": "main_gpu",
    "--split-mode": "split_mode",
    "--tensor-split": "tensor_split",
    "--flash-attn": "flash_attn",
    "--mlock": "mlock",
    "--no-mmap": "no_mmap",
    "--cache-type-k": "cache_type_k",
    "--cache-type-v": "cache_type_v",
    "--rope-scaling": "rope_scaling",
    "--temp": "temperature",
    "--top-k": "top_k",
    "--top-p": "top_p",
    "--repeat-penalty": "repeat_penalty",
    "--mirostat": "mirostat",
    "--seed": "seed",
  };
  return m[flag] ?? null;
}
