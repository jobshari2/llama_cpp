import { create } from "zustand";
import { DEFAULT_CONFIG, type LlamaConfig } from "@/lib/api";

type ConfigStore = {
  config: LlamaConfig;
  setConfig: (cfg: LlamaConfig) => void;
  patch: <K extends keyof LlamaConfig>(key: K, value: LlamaConfig[K]) => void;
  reset: () => void;
};

export const useConfigStore = create<ConfigStore>((set) => ({
  config: { ...DEFAULT_CONFIG },
  setConfig: (config) => set({ config }),
  patch: (key, value) => set((s) => ({ config: { ...s.config, [key]: value } })),
  reset: () => set({ config: { ...DEFAULT_CONFIG } }),
}));
