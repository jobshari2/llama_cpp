import * as React from "react";
import { cn } from "@/lib/utils";

export const Select = React.forwardRef<
  HTMLSelectElement,
  React.SelectHTMLAttributes<HTMLSelectElement>
>(({ className, children, ...props }, ref) => (
  <select
    ref={ref}
    className={cn(
      "h-9 rounded-md bg-bg-elevated border border-bg-border px-3 text-sm text-text",
      "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-nv-500/60",
      className
    )}
    {...props}
  >
    {children}
  </select>
));
Select.displayName = "Select";
