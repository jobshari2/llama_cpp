import * as React from "react";
import { cn } from "@/lib/utils";

type Variant = "default" | "outline" | "success" | "warn" | "danger";

const styles: Record<Variant, string> = {
  default: "bg-bg-elevated text-text-muted border border-bg-border",
  outline: "border border-bg-border text-text-muted",
  success: "bg-nv-500/15 text-nv-300 border border-nv-500/30",
  warn: "bg-yellow-500/15 text-yellow-300 border border-yellow-500/30",
  danger: "bg-red-500/15 text-red-300 border border-red-500/30",
};

export function Badge({
  variant = "default",
  className,
  ...props
}: React.HTMLAttributes<HTMLSpanElement> & { variant?: Variant }) {
  return <span className={cn("pill", styles[variant], className)} {...props} />;
}
