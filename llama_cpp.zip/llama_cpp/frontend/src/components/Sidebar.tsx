import { NavLink } from "react-router-dom";
import {
  Cpu, Sliders, Gauge, MessageSquare, Database, Layers, Sparkles, Rocket, Settings,
} from "lucide-react";
import { cn } from "@/lib/utils";

const items = [
  { to: "/", label: "Dashboard", icon: Cpu },
  { to: "/configuration", label: "Configuration", icon: Sliders },
  { to: "/benchmark", label: "Benchmark", icon: Gauge },
  { to: "/playground", label: "Playground", icon: MessageSquare },
  { to: "/models", label: "Models", icon: Database },
  { to: "/presets", label: "Presets", icon: Layers },
  { to: "/optimization", label: "Optimization", icon: Sparkles },
  { to: "/tensorrt", label: "TensorRT-LLM", icon: Rocket },
  { to: "/settings", label: "Settings", icon: Settings },
];

export function Sidebar() {
  return (
    <aside className="w-60 border-r border-bg-border bg-bg-surface flex flex-col">
      <div className="px-5 py-4 flex items-center gap-2 border-b border-bg-border">
        <div className="w-7 h-7 rounded-md bg-nv-500 grid place-items-center text-black font-bold">L</div>
        <div>
          <div className="font-semibold leading-none">LlamaForge</div>
          <div className="text-[11px] text-text-subtle">llama.cpp control panel</div>
        </div>
      </div>
      <nav className="flex-1 p-2 space-y-0.5">
        {items.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            end={to === "/"}
            className={({ isActive }) =>
              cn(
                "flex items-center gap-3 px-3 py-2 rounded-md text-sm transition",
                isActive
                  ? "bg-nv-500/10 text-nv-300 ring-1 ring-nv-500/30"
                  : "text-text-muted hover:text-text hover:bg-bg-elevated"
              )
            }
          >
            <Icon className="w-4 h-4" />
            {label}
          </NavLink>
        ))}
      </nav>
      <div className="p-3 text-[11px] text-text-subtle border-t border-bg-border">
        <div className="font-mono">v0.1.0</div>
        <a href="https://github.com/ggml-org/llama.cpp" target="_blank" rel="noreferrer" className="hover:text-nv-400">
          ggml-org/llama.cpp
        </a>
      </div>
    </aside>
  );
}
