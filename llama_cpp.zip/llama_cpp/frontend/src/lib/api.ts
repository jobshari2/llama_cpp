/* Lightweight typed API client. */

export type Json = Record<string, unknown>;

async function request<T>(method: string, url: string, body?: unknown): Promise<T> {
  const res = await fetch(url, {
    method,
    headers: { "Content-Type": "application/json" },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`${res.status} ${res.statusText}: ${text}`);
  }
  if (res.status === 204) return undefined as T;
  return (await res.json()) as T;
}

export const api = {
  get: <T,>(url: string) => request<T>("GET", url),
  post: <T,>(url: string, body?: unknown) => request<T>("POST", url, body),
  put: <T,>(url: string, body?: unknown) => request<T>("PUT", url, body),
  del: <T,>(url: string) => request<T>("DELETE", url),
};

/* Hardware */
export type GpuInfo = {
  index: number;
  name: string;
  vram_total_mb: number;
  vram_free_mb: number;
  vram_used_mb: number;
  cuda_version?: string | null;
  driver_version?: string | null;
  compute_capability?: string | null;
  tensor_cores?: boolean | null;
  temperature_c?: number | null;
  power_w?: number | null;
  utilization_percent?: number | null;
};

export type HardwareSnapshot = {
  platform: string;
  os: string;
  hostname: string;
  gpus: GpuInfo[];
  cpu: {
    physical_cores: number;
    logical_cores: number;
    architecture: string;
    model?: string | null;
    base_freq_mhz?: number | null;
    current_freq_mhz?: number | null;
    load_percent?: number | null;
  };
  memory: {
    total_mb: number;
    free_mb: number;
    used_mb: number;
    swap_total_mb: number;
    swap_free_mb: number;
  };
  storage: {
    devices: Array<{
      mount: string;
      fstype?: string | null;
      total_gb: number;
      free_gb: number;
      is_nvme?: boolean | null;
      is_ssd?: boolean | null;
    }>;
  };
  jetson: {
    is_jetson: boolean;
    model?: string | null;
    jetpack_version?: string | null;
    nvpmodel?: string | null;
    jetson_clocks_active?: boolean | null;
    cuda_version?: string | null;
    tensorrt_version?: string | null;
  };
  captured_at: string;
};

/* Llama config */
export type LlamaConfig = {
  model_path: string;
  threads: number;
  ctx_size: number;
  batch_size: number;
  ubatch_size: number;
  n_predict: number;
  gpu_layers: number;
  main_gpu: number;
  split_mode: "none" | "layer" | "row";
  tensor_split?: string | null;
  flash_attn: boolean;
  mlock: boolean;
  no_mmap: boolean;
  cache_type_k: "f32" | "f16" | "q8_0" | "q4_0";
  cache_type_v: "f32" | "f16" | "q8_0" | "q4_0";
  rope_scaling?: "none" | "linear" | "yarn" | null;
  rope_freq_base?: number | null;
  rope_freq_scale?: number | null;
  temperature: number;
  top_k: number;
  top_p: number;
  repeat_penalty: number;
  mirostat: number;
  seed: number;
  extra_args: string[];
};

export type ParamMeta = {
  flag: string;
  name: string;
  category: string;
  type: "int" | "float" | "bool" | "string" | "enum";
  default?: unknown;
  minimum?: number | null;
  maximum?: number | null;
  enum?: string[] | null;
  recommended?: unknown;
  beginner: string;
  advanced: string;
  perf_impact: "none" | "low" | "medium" | "high";
  vram_impact: "none" | "low" | "medium" | "high";
  latency_impact: "none" | "low" | "medium" | "high";
  risk: "none" | "low" | "medium" | "high";
};

/* Models */
export type ModelRecord = {
  id?: string;
  name: string;
  path: string;
  size_bytes: number;
  architecture?: string | null;
  quantization?: string | null;
  context_length?: number | null;
  parameter_count?: number | null;
  estimated_vram_mb?: number | null;
  favorite: boolean;
  tags: string[];
};

/* Benchmarks */
export type BenchmarkResult = {
  id?: string;
  label?: string | null;
  config: LlamaConfig;
  prompt_tokens: number;
  generated_tokens: number;
  prompt_eval_tps: number;
  token_gen_tps: number;
  total_seconds: number;
  latency_first_token_ms?: number | null;
  peak_vram_mb?: number | null;
  avg_vram_mb?: number | null;
  peak_ram_mb?: number | null;
  avg_gpu_utilization?: number | null;
  peak_temperature_c?: number | null;
  throttled?: boolean;
  avg_power_w?: number | null;
  success: boolean;
  error?: string | null;
  created_at?: string;
};

/* Presets */
export type Preset = {
  id?: string;
  name: string;
  description: string;
  tags: string[];
  config: LlamaConfig;
  builtin?: boolean;
  icon?: string | null;
};

/* Quantization */
export type QuantInfo = {
  name: string;
  bits_per_weight: number;
  quality: number;
  speed: number;
  expected_vram_mb_for_7b: number;
  description: string;
  use_case: string;
};

export type QuantizationRecommendation = {
  primary: string;
  alternatives: string[];
  reasoning: string;
  estimated_vram_mb?: number | null;
  quality_score?: number | null;
  speed_score?: number | null;
  table: QuantInfo[];
};

export const DEFAULT_CONFIG: LlamaConfig = {
  model_path: "",
  threads: 4,
  ctx_size: 4096,
  batch_size: 512,
  ubatch_size: 512,
  n_predict: 256,
  gpu_layers: 999,
  main_gpu: 0,
  split_mode: "layer",
  tensor_split: null,
  flash_attn: true,
  mlock: false,
  no_mmap: false,
  cache_type_k: "f16",
  cache_type_v: "f16",
  rope_scaling: "none",
  rope_freq_base: null,
  rope_freq_scale: null,
  temperature: 0.8,
  top_k: 40,
  top_p: 0.95,
  repeat_penalty: 1.1,
  mirostat: 0,
  seed: -1,
  extra_args: [],
};
