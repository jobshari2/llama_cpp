import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function fmtBytes(bytes: number, digits = 1) {
  if (!bytes) return "0 B";
  const units = ["B", "KB", "MB", "GB", "TB"];
  const i = Math.min(units.length - 1, Math.floor(Math.log(bytes) / Math.log(1024)));
  return `${(bytes / Math.pow(1024, i)).toFixed(digits)} ${units[i]}`;
}

export function fmtMb(mb?: number | null, digits = 0) {
  if (mb == null) return "—";
  if (mb >= 1024) return `${(mb / 1024).toFixed(digits + 1)} GB`;
  return `${mb.toFixed(digits)} MB`;
}

export function fmtNumber(n?: number | null, digits = 1) {
  if (n == null || Number.isNaN(n)) return "—";
  return n.toFixed(digits);
}
