import { Routes, Route, Navigate } from "react-router-dom";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Sidebar } from "@/components/Sidebar";
import { Dashboard } from "@/pages/Dashboard";
import { Configuration } from "@/pages/Configuration";
import { BenchmarkPage } from "@/pages/Benchmark";
import { Playground } from "@/pages/Playground";
import { Models } from "@/pages/Models";
import { Presets } from "@/pages/Presets";
import { Optimization } from "@/pages/Optimization";
import { TensorRT } from "@/pages/TensorRT";
import { SettingsPage } from "@/pages/Settings";

export default function App() {
  return (
    <TooltipProvider delayDuration={150}>
      <div className="flex h-screen overflow-hidden">
        <Sidebar />
        <main className="flex-1 overflow-y-auto p-8">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/configuration" element={<Configuration />} />
            <Route path="/benchmark" element={<BenchmarkPage />} />
            <Route path="/playground" element={<Playground />} />
            <Route path="/models" element={<Models />} />
            <Route path="/presets" element={<Presets />} />
            <Route path="/optimization" element={<Optimization />} />
            <Route path="/tensorrt" element={<TensorRT />} />
            <Route path="/settings" element={<SettingsPage />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>
      </div>
    </TooltipProvider>
  );
}
